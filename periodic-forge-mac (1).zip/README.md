# Periodic Forge — macOS app

A 3D laboratory for all 118 elements: build reactions in the sandbox, explore bonds in the
Deep Forge, look up every reaction in the Lexicon, and ask your own local AI model.

This is your Base44 export wrapped as a real Mac app (Electron). Everything runs on your Mac —
the lab, the lexicon and the sandbox need no internet.

## Get the app (pick one)

### A. Build it on your Mac (about 5 minutes)

1. Install Node.js (LTS) from <https://nodejs.org>, or run `brew install node`.
2. Open Terminal, go into this folder, then run:

   ```bash
   npm install
   npm run dist:mac
   ```

3. Open the new `release/` folder. You get a `.dmg` for your Mac's chip (the file name
   ends in `-arm64` on Apple Silicon). Open it and drag **Periodic Forge** into Applications.

Just want to try it without packaging? `npm start` opens it straight away.
Need both Apple Silicon and Intel builds plus `.zip` files? `npm run dist:mac:all`.

### B. Let GitHub build it and host the download (no Node needed)

1. Create a **public** repository on GitHub and push this folder to it:

   ```bash
   git init && git add . && git commit -m "Periodic Forge"
   git branch -M main
   git remote add origin https://github.com/YOUR-NAME/periodic-forge.git
   git push -u origin main
   ```

2. Open the repo's **Actions** tab → **Build macOS app** → **Run workflow**.
   (If the tab asks you to enable workflows, say yes. Also check
   **Settings → Actions → General → Workflow permissions** is set to *Read and write*.)
3. After about 5 minutes the app appears under **Releases** on the repo's front page.
   Share `https://github.com/YOUR-NAME/periodic-forge/releases/latest` — anyone can download
   the `.dmg` (the `-arm64` file for Apple Silicon Macs, the other for Intel).

To publish a new version later: bump `version` in `package.json`, push, and run the workflow again
(or push a tag such as `v1.0.1`).

## First launch

- **Built on your own Mac (option A):** it just opens.
- **Downloaded from GitHub (option B):** macOS shows a warning because the app is not notarized
  (Apple charges $99/year for that). Open **System Settings → Privacy & Security**, scroll down and
  click **Open Anyway**. Or run this once in Terminal:

  ```bash
  xattr -cr "/Applications/Periodic Forge.app"
  ```

## The AI lab (LM Studio)

The "Accurate mode" panel in the Sandbox answers through a model running on your Mac.

1. Install [LM Studio](https://lmstudio.ai) and download any chat model.
2. In LM Studio: **Developer** tab → **Start Server** (port 1234).
3. In Periodic Forge: Sandbox → **Accurate mode** → **Use my own LM Studio model** → **Detect** → pick your model.

You do **not** need to switch on "Enable CORS" in LM Studio — the app handles that itself.
The connection is remembered between launches.

## What changed from the Base44 export

| Area | Base44 export | Mac app |
| --- | --- | --- |
| Login | Base44 login gate | Removed — the app opens straight in |
| AI lab | Hosted Gemini (needs Base44) | Your LM Studio model only |
| Fonts | Loaded from Google Fonts | Bundled in the app (works offline) |
| Base44 editor/analytics scripts | Injected by the Vite plugin | Not included |
| "Install to Dock" help | Shown | Hidden (it already is an app) |

The normal web build (`npm run build`) is untouched: all the changes sit behind a
`STANDALONE` flag (`src/lib/standalone.js`) that only the desktop build switches on.

## Project layout

- `electron/main.cjs` — the native window, the `app://` file server, the LM Studio bridge, the Mac menu
- `src/` — the React app (your Base44 code)
- `build/icon.png` — app icon (1024×1024); replace it to change the Dock icon
- `vite.config.js` — `--mode standalone` is the desktop build
- `package.json` → `build` — packaging settings (name, bundle id, targets)

## Good to know

- The app is ad-hoc signed so it runs on Apple Silicon without a paid developer account.
- To change the app name or bundle id, edit `build.productName` and `build.appId` in `package.json`.
- If you keep editing the app in Base44, export again and copy the new `src/` files over this
  folder's `src/` — the standalone switches in `AuthContext.jsx`, `AiLab.jsx`,
  `LocalModelDialog.jsx`, `ModeNav.jsx`, `PageNotFound.jsx` and `main.jsx` are the ones to keep.
