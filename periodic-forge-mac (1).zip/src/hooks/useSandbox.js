import { useCallback, useMemo, useState } from 'react';
import { ELEMENTS, byZ, CATEGORIES, naturalForm } from '@/data/elements';
import { react, reactWithAir, reactWithWater, applyHeat } from '@/data/reactions';
import { findAdvanced, nextSteps } from '@/data/molecules';
import { synthesize } from '@/data/synthesis';
import { classifyBond } from '@/data/bonds';

const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const MAX_SPECIMENS = 16;
const shortName = (s) => (s ? s.split(' (')[0] : '');
const union = (a = [], b = []) => [...new Set([...a, ...b])].sort((x, y) => x - y);

const elBySymbol = (symbol) =>
  ELEMENTS.find((e) => e.symbol.toLowerCase() === String(symbol || '').trim().toLowerCase());

// "2Na + Cl₂ → 2NaCl" → "NaCl"
export function formulaFromEquation(eq) {
  if (!eq) return '';
  const tail = eq.split(/[→⇌]/).pop();
  if (!tail) return '';
  const first = tail.trim().split(' + ')[0].trim();
  return first
    .replace(/^[0-9]+/, '')
    .replace(/\s*\([a-z0-9]+\)$/i, '')
    .replace(/^\(|\)$/g, '')
    .trim();
}

const makeElement = (el, x = 0.5, y = 0.5) => ({
  id: uid(),
  kind: 'element',
  Z: el.Z,
  set: [el.Z],
  label: naturalForm(el),
  name: el.name,
  cat: el.cat,
  state: el.state,
  color: CATEGORIES[el.cat].color,
  bond: null,
  x,
  y,
});

const makeCompound = (adv, zs, x, y) => ({
  id: uid(),
  kind: 'compound',
  set: zs,
  label: adv.formula,
  formula: adv.formula,
  name: adv.name,
  bond: adv.bond,
  state: adv.state || 'solid',
  color: adv.color || '#8be9fd',
  x,
  y,
});

// Resolve what happens when specimen a meets specimen b.
function evaluatePair(a, b, highEnergy, deepForge) {
  const zs = union(a.set, b.set);
  const bothElements = a.kind === 'element' && b.kind === 'element';
  const adv = findAdvanced(zs) || synthesize(zs, { deep: deepForge });

  if (adv) {
    const already = [a, b].find((s) => s.kind === 'compound' && s.formula === adv.formula);
    if (already) {
      return {
        result: {
          ok: false,
          energy: 'none',
          bond: null,
          set: zs,
          equation: `${already.label} + ${(already === a ? b : a).label} → (no change)`,
          product: `${already.label} is already complete`,
          description: `${adv.formula} already holds every element in this mixture. Add a different element to push the structure further.`,
          suggestions: nextSteps(zs),
        },
        product: null,
      };
    }
    return {
      result: {
        ok: true,
        bond: adv.bond,
        energy: adv.energy,
        equation: `${a.label} + ${b.label} → ${adv.formula}`,
        product: `${adv.name} · ${adv.formula}`,
        description: adv.desc,
        set: zs,
      },
      product: makeCompound(adv, zs, (a.x + b.x) / 2, (a.y + b.y) / 2),
    };
  }

  if (!deepForge) {
    const gated = synthesize(zs, { deep: true });
    if (gated) {
      return {
        result: {
          ok: false,
          energy: 'none',
          bond: gated.bond,
          set: zs,
          equation: `${a.label} + ${b.label} → ${gated.formula}`,
          product: `${gated.name} · needs Deep Forge`,
          description: `${gated.desc} Unlock the Deep Forge to actually build this structure.`,
          locked: true,
        },
        product: null,
      };
    }
  }

  if (bothElements) {
    const elA = byZ[a.Z];
    const elB = byZ[b.Z];
    const r = react(elA, elB, { highEnergy });
    const bond = classifyBond(elA, elB);
    if (!r.ok) return { result: { ...r, bond: null, set: zs }, product: null };

    const formula = formulaFromEquation(r.equation) || shortName(r.product);
    const nonmetal = [a, b].find((s) => ['nonmetal', 'halogen'].includes(s.cat)) || b;
    const product = {
      id: uid(),
      kind: 'compound',
      set: zs,
      label: formula,
      formula,
      name: shortName(r.product),
      bond,
      state: 'solid',
      color: CATEGORIES[nonmetal.cat]?.color || '#8be9fd',
      x: (a.x + b.x) / 2,
      y: (a.y + b.y) / 2,
    };
    return { result: { ...r, bond, set: zs, formula }, product };
  }

  const steps = nextSteps(zs);
  return {
    result: {
      ok: false,
      energy: 'none',
      bond: null,
      set: zs,
      equation: `${a.label} + ${b.label} → (no new bond)`,
      product: 'These do not bond further',
      description: steps.length
        ? `There is no stable structure for exactly these atoms in the model. Add ${steps.map((s) => s.symbol).join(' or ')} and it will close into ${steps[0].formula} (${steps[0].name}).`
        : 'These specimens already share their bonding capacity — try a different partner.',
      suggestions: steps,
    },
    product: null,
  };
}

export default function useSandbox() {
  const [specimens, setSpecimens] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState([]);
  const [highEnergy, setHighEnergy] = useState(false);
  const [deepForge, setDeepForge] = useState(false);
  const [demoNote, setDemoNote] = useState(null);
  const [undoStack, setUndoStack] = useState([]);

  const selected = useMemo(
    () => specimens.find((s) => s.id === selectedId) || null,
    [specimens, selectedId]
  );

  const pushLog = (r) => {
    setHistory((prev) => [{ id: uid(), ok: r.ok, equation: r.equation, bond: r.bond }, ...prev].slice(0, 8));
  };

  const addElement = (el) => {
    setSpecimens((prev) => {
      if (prev.length >= MAX_SPECIMENS) return prev;
      return [...prev, makeElement(el, 0.18 + Math.random() * 0.64, 0.2 + Math.random() * 0.6)];
    });
    setResult(null);
  };

  const addBySymbol = (symbol) => {
    const el = elBySymbol(symbol);
    if (el) addElement(el);
  };

  const moveSpecimen = (id, x, y) => {
    setSpecimens((prev) => prev.map((s) => (s.id === id ? { ...s, x, y } : s)));
  };

  const removeSpecimen = (id) => {
    setSpecimens((prev) => prev.filter((s) => s.id !== id));
    setSelectedId((cur) => (cur === id ? null : cur));
  };

  const combine = (aId, bId) => {
    const a = specimens.find((s) => s.id === aId);
    const b = specimens.find((s) => s.id === bId);
    if (!a || !b) return;

    const { result: r, product } = evaluatePair(a, b, highEnergy, deepForge);
    setResult(r);
    pushLog(r);
    if (!product) return;

    // Snapshot before the merge so a wrong fusion can be stepped back
    setUndoStack((prev) => [{ specimens, selectedId }, ...prev].slice(0, 12));
    setSpecimens(specimens.filter((s) => s.id !== a.id && s.id !== b.id).concat(product));
    setSelectedId(product.id);
  };

  const undo = () => {
    if (!undoStack.length) return;
    const [last, ...rest] = undoStack;
    setSpecimens(last.specimens);
    setSelectedId(last.selectedId);
    setResult(null);
    setUndoStack(rest);
  };

  const target = () => selected || specimens[specimens.length - 1] || null;

  const runEnvironment = (kind) => {
    const t = target();
    if (!t || t.kind !== 'element') return;
    const el = byZ[t.Z];
    const r = kind === 'heat' ? applyHeat(el) : kind === 'air' ? reactWithAir(el) : reactWithWater(el);
    setResult(r);
    pushLog(r);
  };

  const clearAll = () => {
    setSpecimens([]);
    setSelectedId(null);
    setResult(null);
    setUndoStack([]);
  };

  // Replays an AI-authored demo on the chamber, one visible step at a time.
  const runPlan = useCallback(
    async (steps) => {
      let list = [];
      setSpecimens([]);
      setSelectedId(null);
      setResult(null);
      setUndoStack([]);

      for (const step of steps) {
        if (step.op === 'clear') {
          list = [];
          setSpecimens([]);
          setSelectedId(null);
          setDemoNote(step.note || 'Clearing the chamber');
          await sleep(350);
          continue;
        }

        if (step.op === 'add') {
          const el = elBySymbol(step.symbol);
          if (!el || list.length >= MAX_SPECIMENS) continue;
          const sp = makeElement(el, 0.26 + Math.random() * 0.48, 0.26 + Math.random() * 0.48);
          list = [...list, sp];
          setSpecimens(list);
          setSelectedId(sp.id);
          setDemoNote(step.note || `Placing ${el.name}`);
          await sleep(620);
          continue;
        }

        if (step.op === 'combine') {
          if (list.length < 2) continue;
          const b = list[list.length - 1];
          const a = list[list.length - 2];
          const { result: r, product } = evaluatePair(a, b, highEnergy, deepForge);
          setResult(r);
          pushLog(r);
          if (!product) {
            setDemoNote(step.note || `${a.label} + ${b.label} — no reaction`);
            await sleep(750);
            continue;
          }
          list = [...list.slice(0, -2), product];
          setSpecimens(list);
          setSelectedId(product.id);
          setDemoNote(step.note || `Bonding ${a.label} + ${b.label} → ${product.label}`);
          await sleep(900);
          continue;
        }

        if (['heat', 'air', 'water'].includes(step.op)) {
          const t = list[list.length - 1];
          if (!t || t.kind !== 'element') {
            setDemoNote(step.note || `${step.op} has no effect on ${t?.label || 'an empty chamber'}`);
            await sleep(500);
            continue;
          }
          const el = byZ[t.Z];
          const r =
            step.op === 'heat' ? applyHeat(el) : step.op === 'air' ? reactWithAir(el) : reactWithWater(el);
          setResult(r);
          pushLog(r);
          setDemoNote(step.note || `${t.name} + ${step.op}`);
          await sleep(800);
        }
      }

      setDemoNote(null);
    },
    [highEnergy, deepForge]
  );

  return {
    specimens,
    selected,
    result,
    history,
    undo,
    canUndo: undoStack.length > 0,
    highEnergy,
    deepForge,
    demoNote,
    setHighEnergy,
    setDeepForge,
    setSelectedId,
    addElement,
    addBySymbol,
    moveSpecimen,
    removeSpecimen,
    combine,
    doHeat: () => runEnvironment('heat'),
    doAir: () => runEnvironment('air'),
    doWater: () => runEnvironment('water'),
    clearAll,
    runPlan,
  };
}