// Bond classification used by the sandbox to describe how two specimens join.

const METAL_CATS = ['alkali', 'alkaline', 'transition', 'post', 'lanthanide', 'actinide'];

export const isMetalCat = (cat) => METAL_CATS.includes(cat);

export const BONDS = {
  ionic: {
    label: 'Ionic',
    color: '#38bdf8',
    blurb: 'Electrons are transferred outright — a lattice of cations and anions held by electrostatic attraction.',
  },
  covalent: {
    label: 'Covalent',
    color: '#a3e635',
    blurb: 'Electrons are shared evenly between atoms of similar electronegativity.',
  },
  polar: {
    label: 'Polar covalent',
    color: '#facc15',
    blurb: 'Electrons are shared unequally, leaving δ+ and δ− ends — the reason these molecules dissolve and conduct.',
  },
  coordinate: {
    label: 'Coordinate (dative)',
    color: '#c084fc',
    blurb: 'One atom donates both electrons of the bond — how NH₄⁺, hydrates and metal complexes are built.',
  },
  metallic: {
    label: 'Metallic',
    color: '#94a3b8',
    blurb: 'A sea of delocalised electrons shared across a lattice of cations — this is what makes metals conduct.',
  },
  network: {
    label: 'Network covalent',
    color: '#34d399',
    blurb: 'A continuous three-dimensional covalent lattice, which is why these solids are brutally hard and high-melting.',
  },
  hydrogen: {
    label: 'Hydrogen-bonded',
    color: '#f472b6',
    blurb: 'A strong dipole attraction between a δ+ hydrogen and a lone pair on N, O or F.',
  },
};

// ΔEN thresholds: >1.7 ionic, 0.4–1.7 polar covalent, <0.4 pure covalent.
export function classifyBond(a, b) {
  if (!a || !b) return null;
  const aMetal = isMetalCat(a.cat);
  const bMetal = isMetalCat(b.cat);
  if (aMetal && bMetal) return 'metallic';
  if (a.en == null || b.en == null) return aMetal !== bMetal ? 'ionic' : 'covalent';
  const d = Math.abs(a.en - b.en);
  if (d >= 1.7) return 'ionic';
  if (d >= 0.4) return 'polar';
  return 'covalent';
}