// Ground-state atomic structure, derived from the Madelung filling order
// with the published ground-state exceptions.

const SUBSHELL = ['s', 'p', 'd', 'f'];

// [principal n, subshell l, capacity] in filling order
const ORDER = [
  [1, 0, 2], [2, 0, 2], [2, 1, 6], [3, 0, 2], [3, 1, 6], [4, 0, 2], [3, 2, 10],
  [4, 1, 6], [5, 0, 2], [4, 2, 10], [5, 1, 6], [6, 0, 2], [4, 3, 14], [5, 2, 10],
  [6, 1, 6], [7, 0, 2], [5, 3, 14], [6, 2, 10], [7, 1, 6],
];

const NOBLE = { 2: 'He', 10: 'Ne', 18: 'Ar', 36: 'Kr', 54: 'Xe', 86: 'Rn' };
const NOBLE_Z = [2, 10, 18, 36, 54, 86];

const SUP = { 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
const sup = (n) => String(n).split('').map((d) => SUP[d]).join('');

// Published ground-state configurations that break the Madelung rule
const EXCEPTIONS = {
  24: { core: 'Ar', parts: ['3d⁵', '4s¹'] },
  29: { core: 'Ar', parts: ['3d¹⁰', '4s¹'] },
  41: { core: 'Kr', parts: ['4d⁴', '5s¹'] },
  42: { core: 'Kr', parts: ['4d⁵', '5s¹'] },
  44: { core: 'Kr', parts: ['4d⁷', '5s¹'] },
  45: { core: 'Kr', parts: ['4d⁸', '5s¹'] },
  46: { core: 'Kr', parts: ['4d¹⁰'] },
  47: { core: 'Kr', parts: ['4d¹⁰', '5s¹'] },
  57: { core: 'Xe', parts: ['5d¹', '6s²'] },
  58: { core: 'Xe', parts: ['4f¹', '5d¹', '6s²'] },
  64: { core: 'Xe', parts: ['4f⁷', '5d¹', '6s²'] },
  78: { core: 'Xe', parts: ['4f¹⁴', '5d⁹', '6s¹'] },
  79: { core: 'Xe', parts: ['4f¹⁴', '5d¹⁰', '6s¹'] },
  89: { core: 'Rn', parts: ['6d¹', '7s²'] },
  90: { core: 'Rn', parts: ['6d²', '7s²'] },
  91: { core: 'Rn', parts: ['5f²', '6d¹', '7s²'] },
  92: { core: 'Rn', parts: ['5f³', '6d¹', '7s²'] },
  93: { core: 'Rn', parts: ['5f⁴', '6d¹', '7s²'] },
  96: { core: 'Rn', parts: ['5f⁷', '6d¹', '7s²'] },
  103: { core: 'Rn', parts: ['5f¹⁴', '7s²', '7p¹'] },
};

function occupancy(z) {
  const out = [];
  let left = z;
  for (let i = 0; i < ORDER.length && left > 0; i++) {
    const [n, l, cap] = ORDER[i];
    const take = Math.min(cap, left);
    out.push({ n, l, count: take, key: `${n}${SUBSHELL[l]}` });
    left -= take;
  }
  return out;
}

export function electronConfiguration(z) {
  if (!z) return '';
  const ex = EXCEPTIONS[z];
  if (ex) return `[${ex.core}] ${ex.parts.join(' ')}`;

  const coreZ = [...NOBLE_Z].reverse().find((c) => c < z) || 0;
  const all = occupancy(z);
  const rest = all
    .slice(coreZ ? occupancy(coreZ).length : 0)
    .sort((a, b) => a.n - b.n || a.l - b.l)
    .map((o) => o.key + sup(o.count))
    .join(' ');

  return coreZ ? `[${NOBLE[coreZ]}] ${rest}` : rest;
}

// Blocks whose differentiating electron is not the leading subshell of the exception
const BLOCK_FIX = { 24: 'd', 29: 'd', 41: 'd', 42: 'd', 44: 'd', 45: 'd', 46: 'd', 47: 'd', 57: 'd', 78: 'd', 79: 'd', 103: 'p' };

export function blockOf(z) {
  if (!z) return '';
  if (BLOCK_FIX[z]) return BLOCK_FIX[z];
  const ex = EXCEPTIONS[z];
  if (ex) {
    const m = ex.parts[0].match(/[spdf]/);
    return m ? m[0] : '';
  }
  const occ = occupancy(z);
  return SUBSHELL[occ[occ.length - 1].l];
}