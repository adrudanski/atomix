// Generative assembler: composes a plausible structure from any set of elements,
// so stacking specimens never dead-ends on the curated tables.
// `deep` unlocks the advanced bond families — coordination complexes, alloys and
// metal-matrix composites.

import { byZ, CATEGORIES } from './elements';
import { CHARGES, ANIONS, NOBLE_METALS } from './chemistry';

const SUB = ['₀', '₁', '₂', '₃', '₄', '₅', '₆', '₇', '₈', '₉'];
const SUP = ['', '⁺', '²⁺', '³⁺', '⁴⁺', '⁵⁺', '⁶⁺', '⁷⁺', '⁸⁺'];
const sub = (n) => String(n).split('').map((d) => SUB[+d]).join('');
const ROMAN = ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII'];
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);
const gcd = (a, b) => (b ? gcd(b, a % b) : a);

const METAL_CATS = ['alkali', 'alkaline', 'transition', 'post', 'lanthanide', 'actinide'];
const ORDER = { alkali: 0, alkaline: 1, lanthanide: 2, actinide: 2, transition: 3, post: 4 };
const isMetal = (e) => METAL_CATS.includes(e.cat);

// Metals that sit at the centre of an oxoanion when another cation is present
const OXOCORE = {
  23: { f: 'VO₃', ch: 1, n: 'vanadate' },
  24: { f: 'CrO₄', ch: 2, n: 'chromate' },
  25: { f: 'MnO₄', ch: 1, n: 'permanganate' },
  26: { f: 'FeO₄', ch: 2, n: 'ferrate' },
  42: { f: 'MoO₄', ch: 2, n: 'molybdate' },
  74: { f: 'WO₄', ch: 2, n: 'tungstate' },
  75: { f: 'ReO₄', ch: 1, n: 'rhenate' },
};

// Oxoacid-formers: core nonmetal + oxygen gives a polyatomic anion
const POLY = {
  5: { f: 'BO₃', ch: 3, n: 'borate', acid: 'boric' },
  6: { f: 'CO₃', ch: 2, n: 'carbonate', acid: 'carbonic', h: { f: 'HCO₃', ch: 1, n: 'bicarbonate' } },
  7: { f: 'NO₃', ch: 1, n: 'nitrate', acid: 'nitric' },
  14: { f: 'SiO₃', ch: 2, n: 'silicate', acid: 'silicic' },
  15: { f: 'PO₄', ch: 3, n: 'phosphate', acid: 'phosphoric', h: { f: 'HPO₄', ch: 2, n: 'hydrogen phosphate' } },
  16: { f: 'SO₄', ch: 2, n: 'sulfate', acid: 'sulfuric', h: { f: 'HSO₄', ch: 1, n: 'bisulfate' } },
  33: { f: 'AsO₄', ch: 3, n: 'arsenate', acid: 'arsenic' },
  34: { f: 'SeO₄', ch: 2, n: 'selenate', acid: 'selenic' },
  52: { f: 'TeO₄', ch: 2, n: 'tellurate', acid: 'telluric' },
};

const HALPOLY = {
  17: { f: 'ClO₃', ch: 1, n: 'chlorate', acid: 'chloric' },
  35: { f: 'BrO₃', ch: 1, n: 'bromate', acid: 'bromic' },
  53: { f: 'IO₃', ch: 1, n: 'iodate', acid: 'iodic' },
};

const ALLOYS = {
  '3-13': ['Lithium–aluminium alloy', 'Li–Al'],
  '12-13': ['Magnalium', 'Mg–Al'],
  '13-21': ['Scandium aluminide', 'Sc–Al'],
  '13-22': ['Titanium aluminide', 'Ti–Al'],
  '13-29': ['Duralumin', 'Al–Cu'],
  '22-28': ['Nitinol', 'Ni–Ti'],
  '24-26': ['Stainless-steel base', 'Fe–Cr'],
  '26-28': ['Invar', 'Fe–Ni'],
  '26-74': ['Tungsten steel', 'Fe–W'],
  '27-28': ['Superalloy base', 'Co–Ni'],
  '29-30': ['Brass', 'Cu–Zn'],
  '29-47': ['Sterling silver', 'Ag–Cu'],
  '29-50': ['Bronze', 'Cu–Sn'],
  '47-79': ['Electrum', 'Au–Ag'],
  '50-82': ['Soft solder', 'Pb–Sn'],
};

const MOLECULES = {
  '6-7': { formula: 'C₂N₂', name: 'Cyanogen', energy: 'strong', desc: 'Two carbon–nitrogen triple bonds make cyanogen — a colourless gas that burns with a violet-pink flame.' },
  '1-6-7': { formula: 'HCN', name: 'Hydrogen cyanide', energy: 'moderate', desc: 'A C≡N triple bond capped with hydrogen: volatile, and one of the most notorious poisons.' },
  '1-7-15': { formula: 'HPN₂', name: 'Phosphorus nitride', energy: 'mild', desc: 'Nitrogen pairs with phosphorus rather than hydrogen here — a polymeric P–N framework.' },
};

const chargeOf = (el) => (CHARGES[el.Z] ? CHARGES[el.Z][0] : 2);

function ionName(el, ch) {
  const states = CHARGES[el.Z] || [ch];
  return states.length > 1 && states.includes(ch) ? `${el.name}(${ROMAN[ch]})` : el.name;
}

function energyFor(metals, z) {
  if (!metals.length) return 'moderate';
  if (metals.some((m) => NOBLE_METALS.has(m.Z))) return 'mild';
  if (metals.some((m) => m.cat === 'alkali' || m.cat === 'alkaline')) {
    return z === 8 || z === 9 ? 'violent' : 'strong';
  }
  if (z === 9) return 'violent';
  return 'moderate';
}

const catColor = (el) => (el && CATEGORIES[el.cat] ? CATEGORIES[el.cat].color : '#8be9fd');

function anionFor(cores, O, H) {
  if (!cores.length) return O ? { f: 'O', ch: 2, n: 'oxide', poly: false, z: 8 } : null;
  const core = cores[0];
  if (O) {
    if (POLY[core.Z]) return { ...POLY[core.Z], poly: true, z: core.Z };
    if (HALPOLY[core.Z] && !H) return { ...HALPOLY[core.Z], poly: true, z: core.Z };
  }
  const simple = ANIONS[core.Z];
  return simple ? { f: simple.sym, ch: simple.ch, n: simple.name, poly: false, z: core.Z } : null;
}

function saltOf(cation, anion, extra = {}) {
  const c = chargeOf(cation);
  const g = gcd(c, anion.ch);
  const nCat = anion.ch / g;
  const nAn = c / g;
  const catPart = `${cation.symbol}${nCat > 1 ? sub(nCat) : ''}`;
  const anPart = `${anion.poly && nAn > 1 ? `(${anion.f})` : anion.f}${nAn > 1 ? sub(nAn) : ''}`;
  const base = catPart + anPart;
  const formula = extra.hydrate ? `${base}·H₂O` : base;
  const name = `${ionName(cation, c)} ${anion.n}${extra.hydrate ? ' hydrate' : ''}`;
  const ratio = nCat > 1 || nAn > 1 ? `${nCat}:${nAn}` : '1:1';

  const desc =
    `${cation.name} gives up ${c} electron${c > 1 ? 's' : ''} to the ${anion.n}${anion.poly ? ' ion' : ''}, and the charges lock into a ${ratio} lattice.` +
    (extra.note || '') +
    (extra.hydrate
      ? ' Water of crystallisation sits in the lattice channels, its oxygen lone pairs coordinated to the cation.'
      : '');

  return {
    formula,
    name,
    bond: extra.hydrate && cation.cat === 'transition' ? 'coordinate' : 'ionic',
    energy: energyFor([cation], anion.z),
    color: catColor(cation),
    state: 'solid',
    desc,
  };
}

function acidSaltOf(cation, anion) {
  const h = anion.h;
  const c = chargeOf(cation);
  const g = gcd(c, h.ch);
  const nCat = h.ch / g;
  const nAn = c / g;
  const formula = `${cation.symbol}${nCat > 1 ? sub(nCat) : ''}${h.f}${nAn > 1 ? sub(nAn) : ''}`;
  return {
    formula,
    name: `${ionName(cation, c)} ${h.n}`,
    bond: 'hydrogen',
    energy: energyFor([cation], anion.z),
    color: catColor(cation),
    state: 'solid',
    desc: `A partially neutralised acid salt: one proton of the ${anion.n} ion is left in place, and that O–H group hydrogen-bonds to its neighbours — stable as a dry powder, reactive the moment water is added.`,
  };
}

function acidOf(core, anion) {
  const n = anion.ch;
  return {
    formula: `H${n > 1 ? sub(n) : ''}${anion.f}`,
    name: `${cap(anion.acid)} acid`,
    bond: 'polar',
    energy: 'moderate',
    color: catColor(core),
    state: 'liquid',
    desc: `With no metal present the protons sit directly on the ${anion.n} ion, giving a molecular acid whose strongly polar O–H bonds dissociate in water.`,
  };
}

function alloyOf(metals) {
  const pair = metals.slice(0, 2).map((m) => m.Z).sort((a, b) => a - b).join('-');
  const known = ALLOYS[pair];
  const syms = metals.map((m) => m.symbol).join('–');
  return {
    formula: metals.map((m) => m.symbol).join('·'),
    name: known ? known[0] : `${syms} alloy`,
    bond: 'metallic',
    energy: 'mild',
    color: catColor(metals[0]),
    state: 'solid',
    desc: `${metals.map((m) => m.name).join(' and ')} dissolve into each other's lattice instead of forming a compound — a metallic solid solution. ${known ? `That is the family behind ${known[0].toLowerCase()}.` : 'The atoms trade places freely, so composition drifts while the lattice stays intact.'}`,
  };
}

function mixedOxideOf(metals) {
  const a = metals[0];
  const b = metals[1];
  const ca = chargeOf(a);
  const cb = chargeOf(b);
  let best = null;
  for (let na = 1; na <= 4; na += 1) {
    for (let nb = 1; nb <= 4; nb += 1) {
      const total = na * ca + nb * cb;
      if (total % 2) continue;
      const nO = total / 2;
      const atoms = na + nb + nO;
      if (!best || atoms < best.atoms) best = { na, nb, nO, atoms };
    }
  }
  if (!best) return null;
  const formula = `${a.symbol}${best.na > 1 ? sub(best.na) : ''}${b.symbol}${best.nb > 1 ? sub(best.nb) : ''}O${best.nO > 1 ? sub(best.nO) : ''}`;
  const perovskite = best.na === 1 && best.nb === 1 && best.nO === 3;
  return {
    formula,
    name: `${a.name}–${b.name} mixed oxide${perovskite ? ' (perovskite)' : ''}`,
    bond: 'network',
    energy: 'moderate',
    color: catColor(a),
    state: 'solid',
    desc: `Two different cations share a single oxygen lattice${perovskite ? ' in the ABO₃ perovskite arrangement — the structure behind ferroelectrics and high-temperature superconductors' : ' as a double-oxide framework'}.`,
  };
}

function compositeOf(metals, cores, O) {
  const cation = metals[0];
  const matrix = metals.slice(1);
  if (cores.length > 1) return null;
  const anion = anionFor(cores, O, null);
  if (!anion) return null;
  const salt = saltOf(cation, anion);
  const matrixSym = matrix.map((m) => m.symbol).join('–');
  return {
    ...salt,
    formula: `${salt.formula}·${matrixSym}`,
    name: `${salt.name} in a matrix of ${matrixSym}`,
    bond: 'metallic',
    desc: `${salt.desc} The remaining ${matrix.map((m) => m.name.toLowerCase()).join(' and ')} forms the surrounding metal matrix — this is how alloy steels and cemented carbides get their hardness.`,
  };
}

function complexOf(cation, cores, O) {
  const c = chargeOf(cation);
  const k = c >= 3 ? 6 : 4;
  const others = cores.filter((x) => x.Z !== 7);
  const anion = others.length || O ? anionFor(others, O, null) : null;
  const unit = `[${cation.symbol}(NH₃)${sub(k)}]`;
  const bare = ionName(cation, c).replace(cation.name, cation.name.toLowerCase());

  let formula = `${unit}${SUP[c] || ''}`;
  let name = `${k === 4 ? 'Tetra' : 'Hexa'}ammine${bare}`;
  if (anion) {
    const g = gcd(c, anion.ch);
    const nC = anion.ch / g;
    const nA = c / g;
    const counter = `${anion.poly && nA > 1 ? `(${anion.f})` : anion.f}${nA > 1 ? sub(nA) : ''}`;
    formula = `${unit}${nC > 1 ? sub(nC) : ''}${counter}`;
    name = `${name} ${anion.n}`;
  }

  return {
    formula,
    name,
    bond: 'coordinate',
    energy: 'moderate',
    color: catColor(cation),
    state: 'solid',
    desc: `${k} ammonia molecules each push a lone pair from nitrogen into an empty d orbital of ${bare} — ${k} coordinate (dative) bonds. ${
      anion
        ? `The ${anion.n} counter-ions hold the complex in a neutral salt.`
        : 'The complex itself carries a charge, so it only forms alongside a counter-ion in solution.'
    }`,
  };
}

function mergeSalts(primary, second) {
  return {
    ...primary,
    formula: `${primary.formula}·${second.formula}`,
    name: `${primary.name}–${second.name} double salt`,
    bond:
      primary.bond === 'coordinate' || second.bond === 'coordinate' ? 'coordinate' : primary.bond,
    desc: `${primary.desc} A second anion shares the same cations, so both salts crystallise together as a double salt.`,
  };
}

export function synthesize(zs, opts = {}) {
  const deep = !!opts.deep;
  const els = [...new Set(zs)].map((z) => byZ[z]).filter(Boolean);
  if (els.length < 2) return null;

  const metals = els.filter(isMetal).sort((a, b) => (ORDER[a.cat] ?? 5) - (ORDER[b.cat] ?? 5));
  const gas = els.filter((e) => !isMetal(e));
  const H = gas.find((e) => e.Z === 1) || null;
  const O = gas.find((e) => e.Z === 8) || null;
  const cores = gas.filter((e) => e.Z !== 1 && e.Z !== 8);

  // Pure metals mix into an alloy — Deep Forge only
  if (!gas.length) return deep && metals.length >= 2 ? alloyOf(metals) : null;

  // A noble gas refuses to be part of any structure
  if (gas.some((e) => e.cat === 'noble')) return null;

  // A pair is handled by the curated binary tables
  if (els.length < 3) return null;

  if (metals.length >= 2) {
    const coreMetal = metals.find((m) => OXOCORE[m.Z]);
    const cation = metals.find((m) => m !== coreMetal && ['alkali', 'alkaline'].includes(m.cat));
    if (O && coreMetal && cation) {
      const anion = { ...OXOCORE[coreMetal.Z], poly: true, z: coreMetal.Z };
      return saltOf(cation, anion, {
        note: ` ${coreMetal.name} sits at the centre of the anion with four oxygens around it — an oxometallate.`,
      });
    }
    if (!deep) return null;
    if (O && !cores.length) return mixedOxideOf(metals);
    return compositeOf(metals, cores, O);
  }

  if (metals.length === 1) {
    const cation = metals[0];

    if (deep && cation.cat === 'transition' && cores.some((c) => c.Z === 7) && H) {
      return complexOf(cation, cores, O);
    }
    // Hydrogen cannot be placed without oxygen in this model
    if (H && !O) return null;

    const primary = anionFor(cores.length ? [cores[0]] : [], O, H);
    if (!primary) return null;

    const acidSalt = !!primary.h && ['alkali', 'alkaline'].includes(cation.cat);
    let out = acidSalt ? acidSaltOf(cation, primary) : saltOf(cation, primary);

    for (const core of cores.slice(1)) {
      const extra = anionFor([core], O, H);
      if (!extra) return null;
      out = mergeSalts(out, saltOf(cation, extra));
    }

    if (!acidSalt && H && O) {
      const coordinated = cation.cat === 'transition';
      out = {
        ...out,
        formula: `${out.formula}·H₂O`,
        name: `${out.name} hydrate`,
        bond: coordinated ? 'coordinate' : out.bond,
        desc: `${out.desc} Water of crystallisation sits in the lattice channels, its oxygen lone pairs coordinated to the cation.`,
      };
    }

    return out;
  }

  // No metals: acids and molecular species
  if (H && O && cores.length === 1 && POLY[cores[0].Z]) {
    return acidOf(cores[0], { ...POLY[cores[0].Z], poly: true, z: cores[0].Z });
  }

  const mol = MOLECULES[els.map((e) => e.Z).sort((a, b) => a - b).join('-')];
  return mol ? { ...mol, bond: 'polar', color: catColor(cores[0] || els[0]), state: 'gas' } : null;
}

export const DEEP_BONDS = ['coordinate', 'metallic'];