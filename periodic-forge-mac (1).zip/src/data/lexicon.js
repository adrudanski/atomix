// The Lexicon: every element's properties, bond repertoire and complete reaction set.
// Everything is derived from the same engine the sandbox uses, so the dictionary and
// the lab can never disagree — and every one of the 118 elements is covered.

import { ELEMENTS, byZ, CATEGORIES, NOTE, naturalForm } from './elements';
import { electronConfiguration, blockOf } from './atom';
import { react, reactWithAir, reactWithWater, applyHeat, statesOf } from './reactions';
import { classifyBond, BONDS, isMetalCat } from './bonds';

// Reference partners covering every bonding family: hydride, boride, carbide,
// nitride, oxide, fluoride, silicide, phosphide, sulfide, chloride, selenide,
// bromide, iodide.
export const PARTNER_ZS = [1, 5, 6, 7, 8, 9, 14, 15, 16, 17, 34, 35, 53];

export const ENERGY = {
  violent: { label: 'Violent', cls: 'border-red-500/40 bg-red-500/10 text-red-300' },
  strong: { label: 'Strong', cls: 'border-orange-500/40 bg-orange-500/10 text-orange-300' },
  moderate: { label: 'Moderate', cls: 'border-amber-500/40 bg-amber-500/10 text-amber-300' },
  mild: { label: 'Mild', cls: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300' },
  none: { label: 'None', cls: 'border-border bg-secondary/40 text-muted-foreground' },
};

const BLOCK_LABEL = { s: 's-block', p: 'p-block', d: 'd-block', f: 'f-block' };

function valenceElectrons(el, block) {
  if (block === 'f') return 2;
  const g = el.group;
  if (g <= 2) return g;
  if (g >= 13) return g - 10;
  return g;
}

const METALS = ELEMENTS.filter((e) => isMetalCat(e.cat) && e.en != null).sort((a, b) => a.en - b.en);
const NONMETALS = ELEMENTS.filter((e) => !isMetalCat(e.cat) && e.en != null).sort((a, b) => b.en - a.en);

function reactivity(el) {
  if (el.en == null) {
    return { rank: null, total: 0, text: 'No electronegativity value — this element is defined by a closed shell, not by sharing electrons.' };
  }
  if (isMetalCat(el.cat)) {
    const i = METALS.findIndex((m) => m.Z === el.Z);
    return { rank: i + 1, total: METALS.length, text: `Rank ${i + 1} of ${METALS.length} metals by electronegativity — the lower the rank, the more eagerly it gives electrons away.` };
  }
  const i = NONMETALS.findIndex((m) => m.Z === el.Z);
  return { rank: i + 1, total: NONMETALS.length, text: `Rank ${i + 1} of ${NONMETALS.length} non-metals by electronegativity — the higher it sits, the harder it pulls electrons.` };
}

const pick = (r) => ({ ok: r.ok, equation: r.equation, product: r.product, note: r.description, energy: r.energy });

const cache = new Map();

export function dossier(el) {
  if (!el) return null;
  if (cache.has(el.Z)) return cache.get(el.Z);

  const block = blockOf(el.Z);

  const partners = PARTNER_ZS.filter((z) => z !== el.Z).map((z) => {
    const p = byZ[z];
    const r = react(el, p, { highEnergy: true });
    return {
      z: p.Z,
      symbol: p.symbol,
      name: p.name,
      color: CATEGORIES[p.cat].color,
      ok: r.ok,
      equation: r.equation,
      product: r.product,
      note: r.description,
      energy: r.energy,
      bond: r.ok ? classifyBond(el, p) : null,
    };
  });

  const environment = [
    { key: 'air', label: 'In air (O₂)', ...pick(reactWithAir(el)) },
    { key: 'water', label: 'In water', ...pick(reactWithWater(el)) },
    { key: 'heat', label: 'Under strong heat', ...pick(applyHeat(el)) },
  ];

  const groups = {};
  partners.forEach((p) => {
    if (p.ok && p.bond) (groups[p.bond] = groups[p.bond] || []).push(p.symbol);
  });

  const bonds = Object.entries(groups).map(([type, syms]) => ({ type, ...BONDS[type], partners: syms }));
  const add = (type) => {
    if (!bonds.some((b) => b.type === type)) bonds.push({ type, ...BONDS[type], partners: [] });
  };
  if (isMetalCat(el.cat)) add('metallic');
  if ([5, 6, 14].includes(el.Z)) add('network');
  if ([7, 8, 9].includes(el.Z)) add('hydrogen');
  if (['transition', 'lanthanide', 'actinide'].includes(el.cat)) add('coordinate');

  const searchText = [
    el.Z,
    el.symbol,
    el.name,
    CATEGORIES[el.cat].label,
    naturalForm(el),
    ...partners.filter((p) => p.ok).map((p) => p.product),
    ...environment.filter((e) => e.ok).map((e) => e.product),
  ]
    .join(' ')
    .toLowerCase();

  const d = {
    el,
    block,
    blockLabel: BLOCK_LABEL[block] || '—',
    config: electronConfiguration(el.Z),
    natural: naturalForm(el),
    states: statesOf(el),
    valence: valenceElectrons(el, block),
    note: NOTE[el.Z] || null,
    reactivity: reactivity(el),
    environment,
    partners,
    bonds,
    reactiveCount: partners.filter((p) => p.ok).length,
    searchText,
  };

  cache.set(el.Z, d);
  return d;
}

export function allDossiers() {
  return ELEMENTS.map(dossier);
}