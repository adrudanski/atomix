import { byZ, CATEGORIES } from './elements';
import {
  CHARGES, NONMETAL_STATES, ANIONS, MOL_SIZE, NOBLE_METALS, CATION_METALLOIDS,
  IONIC_HYDRIDE, FEATURED, NONMETAL_PAIRS, PAIR_OVERRIDES, AIR, WATER,
} from './chemistry';

const SUB = ['₀', '₁', '₂', '₃', '₄', '₅', '₆', '₇', '₈', '₉'];
const sub = (n) => String(n).split('').map((d) => SUB[+d]).join('');
const gcd = (a, b) => (b ? gcd(b, a % b) : a);
const ROMAN = ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII'];

const isNoble = (e) => e.cat === 'noble';
const isMetal = (e) => ['alkali', 'alkaline', 'transition', 'post', 'lanthanide', 'actinide'].includes(e.cat);
const isHalogen = (e) => e.cat === 'halogen';
const isCation = (e) => isMetal(e) || CATION_METALLOIDS.has(e.Z);
const species = (e) => e.symbol + (MOL_SIZE[e.Z] ? sub(MOL_SIZE[e.Z]) : '');

// Highest sensible charge when the partner is a group 13-15 anion
const ANION_CAP = { 5: 3, 6: 4, 7: 3, 14: 4, 15: 3, 33: 3 };
const SOFT_HEAVY = new Set([50, 80, 81, 82, 83, 84]);
const isRadioactive = (e) => e.Z >= 84 || e.Z === 43 || e.Z === 61;

// Cation label with a Roman numeral whenever the metal has several states
function cationName(el, charge) {
  const states = CHARGES[el.Z] || [2];
  const c = charge || states[0];
  return states.length > 1 && states.includes(c) ? `${el.name}(${ROMAN[c]})` : el.name;
}

// Neutral binary formula from the two ion charges
function ionicFormula(catSym, cCh, anSym, aCh) {
  const g = gcd(cCh, aCh);
  const n1 = aCh / g;
  const n2 = cCh / g;
  return {
    formula: `${catSym}${n1 > 1 ? sub(n1) : ''}${anSym}${n2 > 1 ? sub(n2) : ''}`,
    n1,
    n2,
  };
}

// Balance A + Bₙ → AₓBᵧ by clearing the molecular fraction
function binaryEquation(metal, nMet, nonEl, nNon, formula) {
  const m = MOL_SIZE[nonEl.Z] || 1;
  let ca = nMet * m;
  let cb = nNon;
  let cc = m;
  const g = gcd(gcd(ca, cb), cc) || 1;
  ca /= g; cb /= g; cc /= g;
  const nonSpec = nonEl.symbol + (m > 1 ? sub(m) : '');
  return `${ca > 1 ? ca : ''}${metal.symbol} + ${cb > 1 ? cb : ''}${nonSpec} → ${cc > 1 ? cc : ''}${formula}`;
}

function finish(a, b, res, hi) {
  if (res.hi && !hi) {
    return {
      ok: false,
      equation: `${a.symbol} + ${b.symbol} → (needs high energy)`,
      product: 'No reaction yet',
      description: `${res.d} This one only goes with High Energy mode switched on.`,
      energy: 'none',
      gated: true,
    };
  }
  const ok = res.e !== 'none';
  return { ok, equation: res.eq, product: res.p, description: res.d, energy: res.e };
}

function sameElement(a) {
  const sym = `${a.symbol} + ${a.symbol}`;
  if (isNoble(a)) {
    return { ok: false, equation: `${sym} → (no reaction)`, product: 'No reaction', description: `${a.name} is monatomic and inert — it does not bond even to itself.`, energy: 'none' };
  }
  if (MOL_SIZE[a.Z]) {
    const form = `${a.symbol}${sub(MOL_SIZE[a.Z])}`;
    return { ok: true, equation: `${a.name} → ${form}`, product: `${form} (molecular)`, description: `${a.name} exists as the molecule ${form} under standard conditions.`, energy: 'none' };
  }
  if (isMetal(a)) {
    return { ok: false, equation: `${sym} → metallic lattice`, product: 'Metallic lattice', description: 'Metals do not bond to themselves — they share a sea of delocalised electrons.', energy: 'none' };
  }
  return { ok: false, equation: `${sym} → (no reaction)`, product: 'No reaction', description: 'No chemical change between identical atoms in this model.', energy: 'none' };
}

function ionicEnergy(metal, nonEl) {
  if (NOBLE_METALS.has(metal.Z)) return 'mild';
  const active = metal.cat === 'alkali' || metal.cat === 'alkaline';
  if (active) return nonEl.Z === 8 || isHalogen(nonEl) || nonEl.Z === 16 ? 'violent' : 'strong';
  if (nonEl.Z === 9) return 'violent';
  if (isHalogen(nonEl)) return 'strong';
  if (nonEl.Z === 8) return 'strong';
  if (nonEl.Z === 16) return 'strong';
  return 'moderate';
}

export function react(a, b, opts = {}) {
  const hi = !!opts.highEnergy;
  const lo = Math.min(a.Z, b.Z);
  const hiZ = Math.max(a.Z, b.Z);
  const keys = [`${lo}-${hiZ}`, `${hiZ}-${lo}`];
  const pick = (t) => keys.map((k) => t[k]).find(Boolean);

  const named = pick(FEATURED) || pick(NONMETAL_PAIRS) || pick(PAIR_OVERRIDES);
  if (named) return finish(a, b, named, hi);

  // Anything oxygen already burns in air must also react pair-wise with O₂
  if (a.Z === 8 || b.Z === 8) {
    const ox = reactWithAir(a.Z === 8 ? b : a);
    if (ox.ok) return ox;
  }

  if (a.Z === b.Z) return sameElement(a);

  // Metal + nonmetal → binary ionic (or interstitial) compound
  const cation = isCation(a) && !isCation(b) ? a : isCation(b) && !isCation(a) ? b : null;
  const nonmetal = cation === a ? b : a;
  const anion = ANIONS[nonmetal.Z];

  if (cation && anion) {
    // Soft, low-melting metals do not form nitrides, carbides, borides or silicides
    if (SOFT_HEAVY.has(cation.Z) && [5, 6, 7, 14, 33].includes(nonmetal.Z)) {
      return {
        ok: false,
        equation: `${species(cation)} + ${species(nonmetal)} → (no reaction)`,
        product: 'No reaction',
        description: `${cation.name} is too soft to form a ${anion.name} — it would rather dissolve ${nonmetal.name.toLowerCase()} into its lattice.`,
        energy: 'none',
      };
    }
    if (nonmetal.Z === 1 && !IONIC_HYDRIDE.has(cation.Z)) {
      return {
        ok: true,
        equation: `${cation.symbol} + H₂ → ${cation.symbol}Hₓ (non-stoichiometric)`,
        product: 'Interstitial hydride',
        description: `${cation.name} absorbs hydrogen into its metal lattice rather than forming a true ionic hydride — this is how metal-hydride batteries store hydrogen.`,
        energy: 'mild',
      };
    }
    if (NOBLE_METALS.has(cation.Z)) {
      return finish(a, b, {
        eq: `${cation.symbol} + ${species(nonmetal)} → ${cationName(cation)} ${anion.name}`,
        p: `${cationName(cation)} ${anion.name}`,
        d: `${cation.name} is a noble metal: it resists ${nonmetal.name.toLowerCase()} and only reacts under forcing conditions.`,
        e: 'mild',
        hi: true,
      }, hi);
    }
    // Oxidation by oxygen mirrors the element's air behaviour exactly
    if (nonmetal.Z === 8) {
      const air = reactWithAir(cation);
      if (air.ok) return air;
    }
    const states = CHARGES[cation.Z] || [2];
    const ch = Math.min(states[0], ANION_CAP[nonmetal.Z] || 99);
    const { formula, n1, n2 } = ionicFormula(cation.symbol, ch, anion.sym, anion.ch);
    const highTemp = [5, 6, 7, 14, 33].includes(nonmetal.Z);
    return {
      ok: true,
      equation: binaryEquation(cation, n1, nonmetal, n2, formula),
      product: `${cationName(cation, ch)} ${anion.name}`,
      description: `Redox synthesis: ${cation.name.toLowerCase()} loses ${ch} electron${ch > 1 ? 's' : ''} and ${nonmetal.name.toLowerCase()} gains them, giving the ionic ${anion.name}${highTemp ? ' — this needs a high-temperature furnace' : ''}.`,
      energy: ionicEnergy(cation, nonmetal),
    };
  }

  if (isNoble(a) || isNoble(b)) {
    const noble = isNoble(a) ? a : b;
    const other = noble === a ? b : a;
    return { ok: false, equation: `${species(noble)} + ${species(other)} → (no reaction)`, product: 'No reaction', description: `${noble.name} has a full valence shell and is chemically inert under normal conditions.`, energy: 'none' };
  }

  if (isMetal(a) && isMetal(b)) {
    return { ok: false, equation: `${a.symbol} + ${b.symbol} → alloy`, product: 'Alloy (solid solution)', description: `${a.name} and ${b.name} mix to form an alloy — atoms share a lattice, but no new compound is made.`, energy: 'none' };
  }

  if (isRadioactive(a) || isRadioactive(b)) {
    return { ok: false, equation: `${a.symbol} + ${b.symbol} → (no reaction)`, product: 'No reaction', description: 'One of these is intensely radioactive and decays long before it could combine.', energy: 'none' };
  }

  return { ok: false, equation: `${species(a)} + ${species(b)} → (no reaction)`, product: 'No reaction', description: `${a.name} and ${b.name} do not combine directly under ordinary conditions.`, energy: 'none' };
}

// --- Single-element behaviour ----------------------------------------------

function generatedOxide(el) {
  const states = CHARGES[el.Z];
  if (!states) return null;
  const ch = states[0];
  const { formula, n1, n2 } = ionicFormula(el.symbol, ch, 'O', 2);
  return {
    eq: binaryEquation(el, n1, byZ[8], n2, formula),
    p: `${cationName(el)} oxide`,
    d: `${el.name} is oxidised to the ${ROMAN[ch] || ''} state, forming ${formula}.`,
    e: 'mild',
  };
}

export function reactWithAir(el) {
  const spec = AIR[el.Z];
  if (spec) return { ok: spec.e !== 'none', equation: spec.eq, product: spec.p, description: spec.d, energy: spec.e };

  const gen = generatedOxide(el);
  if (gen) {
    const trace = el.Z >= 93;
    return {
      ok: true,
      equation: gen.eq,
      product: gen.p,
      description: trace
        ? `${el.name} exists only in trace quantities; its oxide is inferred from periodic trends rather than measured in bulk.`
        : `${gen.d} It tarnishes slowly in air and more quickly when heated.`,
      energy: 'mild',
    };
  }
  return { ok: false, equation: `${el.symbol} + air → (no reaction)`, product: 'No reaction', description: `${el.name} does not react with the gases in air under normal conditions.`, energy: 'none' };
}

export function reactWithWater(el) {
  const spec = WATER[el.Z];
  if (spec) return { ok: spec.e !== 'none', equation: spec.eq, product: spec.p, description: spec.d, energy: spec.e };

  if (el.Z === 9) return reactWithAir(el);
  const why = isNoble(el)
    ? `${el.name} is a noble gas and never reacts with water.`
    : isMetal(el)
      ? `${el.name} sits too low in the reactivity series to displace hydrogen from water.`
      : `${el.name} does not react with water under normal conditions.`;
  return { ok: false, equation: `${species(el)} + H₂O → (no reaction)`, product: 'No reaction', description: why, energy: 'none' };
}

export function applyHeat(el) {
  if (el.Z === 53) return { ok: true, energy: 'mild', equation: 'I₂(s) → I₂(g)', product: 'Violet iodine vapour', description: 'Iodine sublimes straight to a striking violet gas without melting first.' };
  if (el.Z === 80) return { ok: true, energy: 'strong', equation: 'Hg(l) → Hg(g)', product: 'Toxic mercury vapour', description: 'Mercury boils at 357 °C, releasing hazardous vapour.' };
  if (el.Z === 35) return { ok: true, energy: 'mild', equation: 'Br₂(l) → Br₂(g)', product: 'Red-brown bromine vapour', description: 'Bromine boils at 59 °C to a dense, choking vapour.' };
  if (isNoble(el)) return { ok: false, equation: `${el.symbol} + heat → (no reaction)`, product: 'No reaction', description: `${el.name} stays inert even when strongly heated.`, energy: 'none' };

  const air = reactWithAir(el);
  if (!air.ok) {
    return { ok: false, equation: `${species(el)} + heat → (no reaction)`, product: 'No reaction', description: `Heating ${el.name.toLowerCase()} in air produces no chemical change.`, energy: 'none' };
  }
  return { ...air, description: `Heated strongly in air — ${air.description}` };
}

// Oxidation states for display
export function statesOf(el) {
  if (NONMETAL_STATES[el.Z]) return NONMETAL_STATES[el.Z];
  const st = CHARGES[el.Z];
  return st ? st.map((c) => `+${c}`) : [];
}

export { CATEGORIES, byZ };