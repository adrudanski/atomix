// Advanced compounds: multi-element structures the sandbox can build by stacking
// specimens. A compound is keyed by the set of element numbers it contains, so a
// specimen dragged onto another resolves to the union of their element sets.

import { byZ } from './elements';

export const ADVANCED = {
  // --- Oxyacids: nonmetal oxide + water -------------------------------------
  '1-6-8': { formula: 'H₂CO₃', name: 'Carbonic acid', bond: 'polar', energy: 'mild', color: '#7dd3fc', state: 'liquid', desc: 'CO₂ dissolving into water gives this weak, unstable acid — the reason rainwater is faintly acidic. It fizzes back to CO₂ when warmed.' },
  '1-7-8': { formula: 'HNO₃', name: 'Nitric acid', bond: 'polar', energy: 'strong', color: '#fb923c', state: 'liquid', desc: 'N₂O₅ + H₂O gives nitric acid: a strong oxidiser, and with ammonia it becomes ammonium nitrate fertiliser.' },
  '1-8-15': { formula: 'H₃PO₄', name: 'Phosphoric acid', bond: 'polar', energy: 'moderate', color: '#fde68a', state: 'liquid', desc: 'P₄O₁₀ hydrating into phosphoric acid — the acid in cola and the phosphate root of every fertiliser.' },
  '1-8-16': { formula: 'H₂SO₄', name: 'Sulfuric acid', bond: 'polar', energy: 'violent', color: '#fbbf24', state: 'liquid', desc: 'SO₃ + H₂O is violently exothermic — add water to acid and it can boil and spit. Sulfuric acid is the most produced industrial chemical on Earth.' },

  // --- Strong bases: metal oxide + water ------------------------------------
  '1-8-3': { formula: 'LiOH', name: 'Lithium hydroxide', bond: 'ionic', energy: 'strong', color: '#ff5f56', state: 'solid', desc: 'Lithium oxide hydrates readily; LiOH is used to scrub carbon dioxide from spacecraft air.' },
  '1-8-11': { formula: 'NaOH', name: 'Sodium hydroxide', bond: 'ionic', energy: 'violent', color: '#ff5f56', state: 'solid', desc: 'Na₂O + H₂O releases a great deal of heat. Caustic soda — the strong base of soap making.' },
  '1-8-19': { formula: 'KOH', name: 'Potassium hydroxide', bond: 'ionic', energy: 'violent', color: '#ff5f56', state: 'solid', desc: 'Caustic potash: an even more aggressive base, used in alkaline batteries.' },
  '1-8-12': { formula: 'Mg(OH)₂', name: 'Magnesium hydroxide', bond: 'ionic', energy: 'moderate', color: '#ff9f43', state: 'solid', desc: 'Milk of magnesia — a mild base that neutralises stomach acid without burning.' },
  '1-8-20': { formula: 'Ca(OH)₂', name: 'Calcium hydroxide (slaked lime)', bond: 'ionic', energy: 'strong', color: '#ff9f43', state: 'solid', desc: 'Quicklime slaking: CaO + H₂O steams and cracks. Its solution, limewater, turns milky with CO₂.' },
  '1-8-56': { formula: 'Ba(OH)₂', name: 'Barium hydroxide', bond: 'ionic', energy: 'strong', color: '#ff9f43', state: 'solid', desc: 'A strong base that absorbs CO₂ so greedily it is used to prove that carbon is present in organic compounds.' },
  '1-8-13': { formula: 'Al(OH)₃', name: 'Aluminium hydroxide', bond: 'ionic', energy: 'mild', color: '#a3e635', state: 'solid', desc: 'Amphoteric: it dissolves in both acid and alkali, which is why aluminium resists attack until the film is broken.' },

  // --- Carbonates -----------------------------------------------------------
  '6-8-3': { formula: 'Li₂CO₃', name: 'Lithium carbonate', bond: 'ionic', energy: 'moderate', color: '#c084fc', state: 'solid', desc: 'The mood-stabilising salt, also the flux that lowers the melting point of glass.' },
  '6-8-11': { formula: 'Na₂CO₃', name: 'Sodium carbonate (soda ash)', bond: 'ionic', energy: 'moderate', color: '#c084fc', state: 'solid', desc: 'Three thousand years of glass making — soda ash lowers silica’s melting point. Also the washing soda of laundry.' },
  '6-8-19': { formula: 'K₂CO₃', name: 'Potassium carbonate (potash)', bond: 'ionic', energy: 'moderate', color: '#c084fc', state: 'solid', desc: 'Leached from wood ash, potash was the first industrial potassium source and the root of the name "potassium".' },
  '6-8-12': { formula: 'MgCO₃', name: 'Magnesium carbonate', bond: 'ionic', energy: 'mild', color: '#c084fc', state: 'solid', desc: 'Magnesite: chalk in gymnasiums, antacid tablets, and a refractory lining for furnaces.' },
  '6-8-20': { formula: 'CaCO₃', name: 'Calcium carbonate', bond: 'network', energy: 'moderate', color: '#e2e8f0', state: 'solid', desc: 'Limestone, chalk and marble — an insoluble ionic lattice that becomes CO₂ and quicklime on heating. Shells and coral are built from it.' },
  '6-8-29': { formula: 'CuCO₃', name: 'Copper(II) carbonate', bond: 'ionic', energy: 'mild', color: '#34d399', state: 'solid', desc: 'The green of weathered copper roofs and bronze statues.' },
  '6-8-56': { formula: 'BaCO₃', name: 'Barium carbonate', bond: 'ionic', energy: 'mild', color: '#e2e8f0', state: 'solid', desc: 'A dense white solid used in rat poison and in the glaze of ceramics.' },

  // --- Bicarbonates: carbonate + water --------------------------------------
  '1-6-8-11': { formula: 'NaHCO₃', name: 'Sodium bicarbonate', bond: 'hydrogen', energy: 'mild', color: '#f8fafc', state: 'solid', desc: 'Bicarbonate of soda: an ionic salt whose HCO₃⁻ ions pair through hydrogen bonds, which is why it is stable as a dry powder but fizzes instantly in acid.' },
  '1-6-8-19': { formula: 'KHCO₃', name: 'Potassium bicarbonate', bond: 'hydrogen', energy: 'mild', color: '#f8fafc', state: 'solid', desc: 'A food-grade leavening agent with the same hydrogen-bonded bicarbonate pairing.' },
  '1-6-8-20': { formula: 'Ca(HCO₃)₂', name: 'Calcium bicarbonate', bond: 'ionic', energy: 'mild', color: '#bae6fd', state: 'solid', desc: 'Temporary hardness in water: it decomposes on boiling to leave limescale — solid CaCO₃ in your kettle.' },

  // --- Nitrates -------------------------------------------------------------
  '1-7-8-11': { formula: 'NaNO₃', name: 'Sodium nitrate', bond: 'ionic', energy: 'mild', color: '#fca5a5', state: 'solid', desc: 'Chile saltpetre: a fertiliser and the oxidiser of early gunpowder.' },
  '1-7-8-19': { formula: 'KNO₃', name: 'Potassium nitrate', bond: 'ionic', energy: 'mild', color: '#fca5a5', state: 'solid', desc: 'Saltpetre — the classic oxidiser. It decomposes on heating to release pure oxygen.' },
  '1-7-8-47': { formula: 'AgNO₃', name: 'Silver nitrate', bond: 'ionic', energy: 'mild', color: '#cbd5e1', state: 'solid', desc: 'Lunar caustic: light-sensitive, so it blackens on the skin and underpins photographic film.' },
  '1-7-8-29': { formula: 'Cu(NO₃)₂', name: 'Copper(II) nitrate', bond: 'ionic', energy: 'mild', color: '#34d399', state: 'solid', desc: 'Intensely blue-green; heating it gives the reddish-brown fumes of NO₂.' },
  '1-7-8-20': { formula: 'Ca(NO₃)₂', name: 'Calcium nitrate', bond: 'ionic', energy: 'mild', color: '#fca5a5', state: 'solid', desc: 'A soluble calcium fertiliser — and the reason concrete corrodes where nitrate reaches it.' },
  '1-7-8-26': { formula: 'Fe(NO₃)₃', name: 'Iron(III) nitrate', bond: 'ionic', energy: 'mild', color: '#fdba74', state: 'solid', desc: 'Pale violet hydrate; a component of the ancient ink that survives on parchment.' },

  // --- Sulfates -------------------------------------------------------------
  '8-16-20': { formula: 'CaSO₄', name: 'Calcium sulfate', bond: 'ionic', energy: 'moderate', color: '#e2e8f0', state: 'solid', desc: 'Gypsum — heated it loses water and sets hard as plaster of Paris.' },
  '8-16-12': { formula: 'MgSO₄', name: 'Magnesium sulfate', bond: 'ionic', energy: 'mild', color: '#e2e8f0', state: 'solid', desc: 'Epsom salt: the hydrate holds its water through hydrogen bonding, and tastes famously bitter.' },
  '8-16-29': { formula: 'CuSO₄', name: 'Copper(II) sulfate', bond: 'ionic', energy: 'moderate', color: '#38bdf8', state: 'solid', desc: 'Blue vitriol — its blue crystals turn white on heating, then blue again in water.' },
  '1-8-16-29': { formula: 'CuSO₄·5H₂O', name: 'Copper sulfate pentahydrate', bond: 'coordinate', energy: 'mild', color: '#2563eb', state: 'solid', desc: 'Four water molecules donate lone pairs into Cu²⁺ as ligands — a true coordinate bond; the fifth is held by hydrogen bonding.' },
  '8-16-26': { formula: 'FeSO₄', name: 'Iron(II) sulfate', bond: 'ionic', energy: 'mild', color: '#86efac', state: 'solid', desc: 'Green vitriol: an old ink ingredient that slowly oxidises to rusty yellow in air.' },
  '8-16-19': { formula: 'K₂SO₄', name: 'Potassium sulfate', bond: 'ionic', energy: 'moderate', color: '#e2e8f0', state: 'solid', desc: 'A chloride-free potassium fertiliser for crops sensitive to salt.' },
  '1-8-16-11': { formula: 'Na₂SO₄', name: 'Sodium sulfate', bond: 'ionic', energy: 'strong', color: '#e2e8f0', state: 'solid', desc: 'Sodium metal fizzing in acid gives violent displacement; NaOH with acid is neutralisation. Both land on the same salt.' },
  '1-8-16-19': { formula: 'K₂SO₄', name: 'Potassium sulfate', bond: 'ionic', energy: 'strong', color: '#e2e8f0', state: 'solid', desc: 'Vigorous displacement or neutralisation, depending on which reactants you started from.' },
  '1-8-16-30': { formula: 'ZnSO₄ + H₂', name: 'Zinc sulfate + hydrogen gas', bond: 'ionic', energy: 'strong', color: '#38bdf8', state: 'solid', desc: 'Zinc dissolves steadily in acid while hydrogen bubbles off — the classroom test for an active metal.' },
  '1-8-16-56': { formula: 'BaSO₄', name: 'Barium sulfate', bond: 'ionic', energy: 'strong', color: '#f8fafc', state: 'solid', desc: 'A white precipitate so insoluble it is safe to swallow — the barium meal that outlines a stomach on an X-ray.' },
  '1-8-16-82': { formula: 'PbSO₄', name: 'Lead(II) sulfate', bond: 'ionic', energy: 'moderate', color: '#cbd5e1', state: 'solid', desc: 'Insoluble white plates that coat the plates of a lead-acid battery as it discharges.' },
  '8-16-13': { formula: 'Al₂(SO₄)₃', name: 'Aluminium sulfate', bond: 'ionic', energy: 'moderate', color: '#e2e8f0', state: 'solid', desc: 'The coagulant that pulls murky particles out of drinking water.' },

  // --- Phosphates and silicates --------------------------------------------
  '8-15-20': { formula: 'Ca₃(PO₄)₂', name: 'Calcium phosphate', bond: 'ionic', energy: 'moderate', color: '#f8fafc', state: 'solid', desc: 'The mineral of bone and tooth enamel — the same phosphate lattice, with OH⁻ in the gaps, is hydroxyapatite.' },
  '8-15-11': { formula: 'Na₃PO₄', name: 'Sodium phosphate', bond: 'ionic', energy: 'moderate', color: '#f8fafc', state: 'solid', desc: 'A strongly alkaline salt used in cleaning agents and buffers.' },
  '8-14-20': { formula: 'CaSiO₃', name: 'Calcium silicate', bond: 'network', energy: 'strong', color: '#94a3b8', state: 'solid', desc: 'Cement and blast-furnace slag: a network silicate that sets hard around aggregate.' },
  '8-14-11': { formula: 'Na₂SiO₃', name: 'Sodium silicate', bond: 'ionic', energy: 'moderate', color: '#bae6fd', state: 'solid', desc: 'Water glass: a syrupy silicate that seals concrete and grows crystal gardens.' },

  // --- Ammonium salts: the dative bond -------------------------------------
  '1-7-17': { formula: 'NH₄Cl', name: 'Ammonium chloride', bond: 'coordinate', energy: 'moderate', color: '#c084fc', state: 'solid', desc: 'The H⁺ from the acid coordinates onto nitrogen’s lone pair — a dative bond. It is the white smoke when NH₃ meets HCl, and it sublimes cleanly.' },
  '1-7-8-16': { formula: '(NH₄)₂SO₄', name: 'Ammonium sulfate', bond: 'coordinate', energy: 'moderate', color: '#c084fc', state: 'solid', desc: 'Two dative N→H bonds holding ammonium cations, plus an ionic sulfate lattice — a staple nitrogen fertiliser.' },

  // --- Halogen compounds ----------------------------------------------------
  '8-17-11': { formula: 'NaClO', name: 'Sodium hypochlorite', bond: 'ionic', energy: 'moderate', color: '#bef264', state: 'solid', desc: 'Bleach. Chlorine disproportionates in cold alkali; never mix it with acid.' },
  '8-17-20': { formula: 'Ca(ClO)₂', name: 'Calcium hypochlorite', bond: 'ionic', energy: 'strong', color: '#bef264', state: 'solid', desc: 'Bleaching powder — the first industrial disinfectant for water supplies.' },
};

const keyOf = (zs) => [...new Set(zs)].sort((a, b) => a - b).join('-');

export const keyFor = keyOf;

export function findAdvanced(zs) {
  if (!zs || zs.length < 3) return null;
  return ADVANCED[keyOf(zs)] || null;
}

// What single element would complete a known compound from this set?
export function nextSteps(zs, limit = 3) {
  const have = new Set(zs);
  const out = [];
  const seen = new Set();
  for (const [k, v] of Object.entries(ADVANCED)) {
    const parts = k.split('-').map(Number);
    if (parts.length !== have.size + 1) continue;
    const extra = parts.filter((p) => !have.has(p));
    if (extra.length !== 1) continue;
    if (seen.has(v.formula)) continue;
    seen.add(v.formula);
    out.push({ Z: extra[0], symbol: byZ[extra[0]].symbol, formula: v.formula, name: v.name });
    if (out.length >= limit) break;
  }
  return out;
}

export const RECIPE_LIST = Object.values(ADVANCED).map((v) => `${v.formula} ${v.name}`).join(', ');