import React from 'react'
import ReactDOM from 'react-dom/client'
import App from '@/App.jsx'
import '@/index.css'
import { STANDALONE } from '@/lib/standalone'

ReactDOM.createRoot(document.getElementById('root')).render(
  <App />
)

// The browser/Dock-installed app keeps working with no network: the shell is cached.
// The packaged Mac app already ships every file inside itself, so it needs no worker.
if ('serviceWorker' in navigator && import.meta.env.PROD && !STANDALONE) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {})
  })
}