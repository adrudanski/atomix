import { useRef, useState } from 'react';
import { ArrowRight } from 'lucide-react';
import PeriodicScene from '@/components/periodic/PeriodicScene';
import ControlPanel from '@/components/periodic/ControlPanel';
import ModeNav from '@/components/ModeNav';
import { CATEGORIES, byZ } from '@/data/elements';
import { react, reactWithAir, reactWithWater, applyHeat } from '@/data/reactions';

export default function PeriodicLab() {
  const [selections, setSelections] = useState([]);
  const [highEnergy, setHighEnergy] = useState(false);
  const [result, setResult] = useState(null);
  const [log, setLog] = useState([]);
  const apiRef = useRef(null);

  const selEls = selections.map((z) => byZ[z]).filter(Boolean);
  const info = selEls.length ? selEls[selEls.length - 1] : null;

  const handleSelect = (z) => {
    setSelections((prev) => {
      if (prev.includes(z)) return prev.filter((x) => x !== z);
      return [...prev, z].slice(-2);
    });
  };

  const pushLog = (r) => {
    setLog((prev) => [{ id: Date.now() + Math.random(), ok: r.ok, equation: r.equation }, ...prev].slice(0, 6));
  };

  const doReact = () => {
    if (selections.length !== 2) return;
    const a = byZ[selections[0]];
    const b = byZ[selections[1]];
    const r = react(a, b, { highEnergy });
    setResult(r);
    pushLog(r);
    if (r.ok) {
      apiRef.current?.blast(a.Z);
      apiRef.current?.blast(b.Z);
    }
  };

  const doAir = () => {
    if (!info) return;
    const r = reactWithAir(info);
    setResult(r);
    pushLog(r);
    if (r.ok) apiRef.current?.blast(info.Z);
  };

  const doWater = () => {
    if (!info) return;
    const r = reactWithWater(info);
    setResult(r);
    pushLog(r);
    if (r.ok) apiRef.current?.blast(info.Z);
  };

  const doHeat = () => {
    if (!info) return;
    const r = applyHeat(info);
    setResult(r);
    pushLog(r);
    if (r.ok) apiRef.current?.blast(info.Z);
  };

  const doImpact = () => {
    if (!info) return;
    apiRef.current?.shockwave();
    const air = reactWithAir(info);
    const r = air.ok
      ? { ...air, description: `Physical force alone does not change a pure element, but the impact energy can trigger its air reaction — ${air.description}` }
      : { ok: false, energy: 'none', equation: `${info.symbol} + force → no chemical change`, product: 'Physical deformation only', description: `${info.name} is fragmented or deformed by the impact, but no new substance is formed.` };
    setResult(r);
    pushLog(r);
  };

  const doQuickPick = (z1, z2) => {
    setSelections([z1, z2]);
    const a = byZ[z1];
    const b = byZ[z2];
    const r = react(a, b, { highEnergy });
    setResult(r);
    pushLog(r);
    if (r.ok) {
      apiRef.current?.blast(z1);
      apiRef.current?.blast(z2);
    }
  };

  const doClear = () => {
    setSelections([]);
    setResult(null);
    apiRef.current?.resetView();
  };

  return (
    <div className="relative h-screen w-full overflow-hidden bg-background">
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse 70% 55% at 50% 45%, hsl(var(--primary)/0.10), transparent 70%), radial-gradient(ellipse 40% 35% at 80% 15%, hsl(var(--chart-4)/0.10), transparent 70%)',
        }}
      />
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.35]"
        style={{
          background:
            'linear-gradient(to bottom, hsl(var(--background)) 0%, transparent 18%, transparent 82%, hsl(var(--background)) 100%)',
        }}
      />

      <PeriodicScene selectedZ={selections} onSelect={handleSelect} apiRef={apiRef} />

      {/* Header */}
      <div className="pointer-events-none absolute left-4 top-4 z-10 max-w-[calc(100%-2rem)] md:left-6 md:top-6">
        <h1 className="type-display text-xl font-bold leading-none text-foreground md:text-[28px]">
          PERIODIC <span className="text-primary">FORGE</span>
        </h1>
        <div className="mt-2 flex items-center gap-2">
          <span className="h-px w-8 bg-primary/60" />
          <p className="type-tech text-[9px] uppercase tracking-[0.18em] text-muted-foreground md:text-[10px]">
            Elemental reaction simulator
          </p>
        </div>
        <p className="mt-1 text-[11px] text-muted-foreground/80 md:text-xs">
          118 elements · oxidation-state engine
        </p>
        <div className="pointer-events-auto mt-3 flex items-center gap-2">
          <ModeNav current="table" />
          <span className="hidden items-center gap-1 type-tech text-[9px] uppercase tracking-widest text-muted-foreground/60 sm:flex">
            <ArrowRight size={10} /> pick two tiles
          </span>
        </div>
      </div>

      {/* Category legend */}
      <div className="pointer-events-none absolute bottom-4 left-4 z-10 hidden max-w-[300px] flex-wrap gap-1.5 md:flex md:left-6 md:bottom-6">
        {Object.entries(CATEGORIES).map(([k, c]) => (
          <span
            key={k}
            className="flex items-center gap-1.5 rounded-full border border-border/50 bg-background/50 px-2 py-0.5 text-[9px] text-muted-foreground backdrop-blur"
          >
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: c.color }} />
            {c.label}
          </span>
        ))}
        <span className="w-full pt-1 type-tech text-[9px] uppercase tracking-widest text-muted-foreground/50">
          Drag to orbit · scroll to zoom · click a tile
        </span>
      </div>

      {/* Control panel */}
      <div className="absolute inset-x-3 bottom-3 z-20 max-h-[52vh] overflow-hidden rounded-2xl border border-border/80 bg-card/85 shadow-[0_30px_90px_-24px_rgba(0,0,0,0.9)] backdrop-blur-2xl md:inset-x-auto md:right-6 md:top-6 md:bottom-6 md:max-h-none md:w-[372px]">
        <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
        <ControlPanel
          sel={selEls}
          info={info}
          result={result}
          log={log}
          highEnergy={highEnergy}
          setHighEnergy={setHighEnergy}
          onRemove={(z) => setSelections((p) => p.filter((x) => x !== z))}
          onClear={doClear}
          onReact={doReact}
          onAir={doAir}
          onWater={doWater}
          onHeat={doHeat}
          onImpact={doImpact}
          onQuickPick={doQuickPick}
        />
      </div>
    </div>
  );
}