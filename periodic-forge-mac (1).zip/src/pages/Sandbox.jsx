import { useEffect, useRef } from 'react';
import { Flame, Wind, Droplets, Trash2, Zap, Undo2, Loader2, Table2 } from 'lucide-react';
import ElementPicker from '@/components/sandbox/ElementPicker';
import Chamber from '@/components/sandbox/Chamber';
import OutcomePanel from '@/components/sandbox/OutcomePanel';
import DeepForge from '@/components/sandbox/DeepForge';
import AiLab from '@/components/sandbox/AiLab';
import ModeNav from '@/components/ModeNav';
import useSandbox from '@/hooks/useSandbox';

const ToolButton = ({ onClick, disabled, icon: Icon, children }) => (
  <button
    onClick={onClick}
    disabled={disabled}
    className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-secondary/50 px-3 py-1.5 text-xs font-medium text-foreground transition hover:border-primary/40 hover:bg-secondary disabled:cursor-not-allowed disabled:opacity-40"
  >
    <Icon size={13} /> {children}
  </button>
);

export default function Sandbox() {
  const sb = useSandbox();
  const busy = !!sb.demoNote;
  const depth = sb.specimens.reduce((max, sp) => Math.max(max, sp.set?.length || 0), 0);
  const seeded = useRef(false);

  // Deep link: /sandbox?element=Fe,Na pre-loads specimens from the lexicon
  useEffect(() => {
    if (seeded.current) return;
    seeded.current = true;
    const param = new URLSearchParams(window.location.search).get('element');
    if (param) param.split(',').forEach((s) => sb.addBySymbol(s.trim()));
  }, [sb]);

  return (
    <div className="relative flex min-h-screen flex-col bg-background lg:h-screen lg:overflow-hidden">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-72"
        style={{
          background:
            'radial-gradient(ellipse 70% 100% at 50% 0%, hsl(var(--primary)/0.08), transparent 72%)',
        }}
      />
      <header className="relative flex items-center justify-between gap-3 border-b border-border px-4 py-3 md:px-6">
        <div className="min-w-0">
          <h1 className="type-display text-lg font-bold leading-tight text-foreground md:text-2xl">
            PERIODIC <span className="text-primary">FORGE</span>
          </h1>
          <p className="truncate text-[11px] text-muted-foreground md:text-xs">
            Reaction sandbox · stack specimens to build advanced bonds
          </p>
        </div>
        <ModeNav current="sandbox" />
      </header>

      <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
        <aside className="h-[34vh] shrink-0 border-b border-border lg:h-auto lg:w-[268px] lg:border-b-0 lg:border-r">
          <ElementPicker onAdd={sb.addElement} />
        </aside>

        <main className="flex min-h-0 flex-1 flex-col gap-3 p-3">
          <div className="flex flex-wrap items-center gap-2">
            <ToolButton onClick={sb.doHeat} icon={Flame}>
              Heat
            </ToolButton>
            <ToolButton onClick={sb.doAir} icon={Wind}>
              Air
            </ToolButton>
            <ToolButton onClick={sb.doWater} icon={Droplets}>
              Water
            </ToolButton>
            <ToolButton onClick={sb.undo} disabled={!sb.canUndo} icon={Undo2}>
              Undo
            </ToolButton>
            <ToolButton onClick={sb.clearAll} disabled={!sb.specimens.length} icon={Trash2}>
              Clear
            </ToolButton>
            <button
              onClick={() => sb.setHighEnergy((v) => !v)}
              aria-pressed={sb.highEnergy}
              className={`inline-flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition ${
                sb.highEnergy
                  ? 'border-amber-500/50 bg-amber-500/10 text-amber-200'
                  : 'border-border bg-secondary/50 text-muted-foreground hover:text-foreground'
              }`}
            >
              <Zap size={13} /> High energy
            </button>
            {busy && (
              <span className="inline-flex items-center gap-1.5 rounded-full border border-primary/40 bg-primary/10 px-2.5 py-1 text-[10px] text-primary">
                <Loader2 size={10} className="animate-spin" /> AI running the sim
              </span>
            )}
            <span className="ml-auto hidden items-center gap-1 text-[10px] text-muted-foreground md:flex">
              <Table2 size={11} /> Drag together to bond · double-click to remove
            </span>
          </div>

          <Chamber
            specimens={sb.specimens}
            selectedId={sb.selected?.id ?? null}
            caption={sb.demoNote}
            onSelect={sb.setSelectedId}
            onMove={sb.moveSpecimen}
            onCombine={sb.combine}
            onRemove={sb.removeSpecimen}
          />

          <AiLab
            chamber={sb.specimens.map((s) => `${s.label}${s.name ? ` (${s.name})` : ''}`)}
            result={sb.result}
            running={busy}
            onRunDemo={sb.runPlan}
          />
        </main>

        <aside className="flex shrink-0 flex-col border-t border-border lg:w-[330px] lg:border-t-0 lg:border-l">
          <DeepForge active={sb.deepForge} depth={depth} onToggle={() => sb.setDeepForge((v) => !v)} />
          <div className="min-h-0 flex-1">
            <OutcomePanel
              result={sb.result}
              selected={sb.selected}
              history={sb.history}
              onAddSuggestion={sb.addBySymbol}
              onUnlock={() => sb.setDeepForge(true)}
            />
          </div>
        </aside>
      </div>
    </div>
  );
}