import { useMemo, useState } from 'react';
import ModeNav from '@/components/ModeNav';
import ElementBrowser from '@/components/lexicon/ElementBrowser';
import ElementDossier from '@/components/lexicon/ElementDossier';
import { allDossiers, dossier } from '@/data/lexicon';
import { byZ } from '@/data/elements';

export default function Lexicon() {
  const all = useMemo(() => allDossiers(), []);
  const [query, setQuery] = useState('');
  const [cat, setCat] = useState('all');
  const [selectedZ, setSelectedZ] = useState(26);

  const items = useMemo(() => {
    const q = query.trim().toLowerCase();
    return all.filter((d) => {
      if (cat !== 'all' && d.el.cat !== cat) return false;
      if (!q) return true;
      return d.searchText.includes(q);
    });
  }, [all, query, cat]);

  const d = dossier(byZ[selectedZ]) || all[0];

  return (
    <div className="relative flex min-h-screen flex-col bg-background lg:h-screen lg:overflow-hidden">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-72"
        style={{
          background:
            'radial-gradient(ellipse 70% 100% at 50% 0%, hsl(var(--primary)/0.08), transparent 72%)',
        }}
      />
      <header className="relative flex items-center justify-between gap-3 border-b border-border px-4 py-3 md:px-6">
        <div>
          <h1 className="type-display text-lg font-bold leading-tight text-foreground md:text-2xl">
            PERIODIC <span className="text-primary">FORGE</span>
          </h1>
          <p className="text-[11px] text-muted-foreground md:text-xs">
            Lexicon · all 118 elements, every bond and reaction
          </p>
        </div>
        <ModeNav current="lexicon" />
      </header>

      <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
        <aside className="h-[38vh] shrink-0 border-b border-border lg:h-auto lg:w-[300px] lg:border-b-0 lg:border-r">
          <ElementBrowser
            items={items}
            query={query}
            setQuery={setQuery}
            cat={cat}
            setCat={setCat}
            selectedZ={d.el.Z}
            onSelect={setSelectedZ}
          />
        </aside>

        <main className="min-h-0 flex-1 overflow-hidden">
          <ElementDossier d={d} />
        </main>
      </div>
    </div>
  );
}