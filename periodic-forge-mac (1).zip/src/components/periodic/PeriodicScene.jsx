import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { ELEMENTS, CATEGORIES, layoutFor } from '@/data/elements';

// How each family behaves under light — metals reflect, gases glow.
const PHYS = {
  alkali: { metal: 0.95, rough: 0.40, emis: 0.06, desat: 0.18 },
  alkaline: { metal: 0.96, rough: 0.34, emis: 0.06, desat: 0.18 },
  transition: { metal: 1.0, rough: 0.20, emis: 0.04, desat: 0.12 },
  post: { metal: 0.88, rough: 0.30, emis: 0.05, desat: 0.14 },
  metalloid: { metal: 0.55, rough: 0.36, emis: 0.09, desat: 0.08 },
  nonmetal: { metal: 0.08, rough: 0.54, emis: 0.14, desat: 0 },
  halogen: { metal: 0.22, rough: 0.46, emis: 0.16, desat: 0 },
  noble: { metal: 0.0, rough: 0.08, emis: 0.30, desat: 0, glass: true },
  lanthanide: { metal: 0.92, rough: 0.26, emis: 0.05, desat: 0.14 },
  actinide: { metal: 0.78, rough: 0.38, emis: 0.12, desat: 0.1 },
};

// True colour of the substance where it is well known; family colour otherwise.
const REAL_COLOR = {
  1: '#dfe9f5', 3: '#cfd6db', 6: '#2f3640', 7: '#cfd8ff', 8: '#a9d5ff', 9: '#eef7a3',
  11: '#d9dde2', 12: '#cfd6db', 13: '#c3ccd4', 14: '#7c8791', 15: '#f2b23c', 16: '#ffe14d',
  17: '#9bf08a', 18: '#9d7bff', 19: '#d5dade', 20: '#d0d6da', 22: '#b9c2c9', 24: '#d7dde2',
  26: '#aab4bd', 28: '#c7ced4', 29: '#c87338', 30: '#b6c0c8', 31: '#cfd6db', 32: '#9aa5af',
  33: '#b0b8bf', 34: '#e0a33c', 35: '#a33b2a', 36: '#a7c7ff', 46: '#d8dee4', 47: '#e9eef3',
  50: '#c8ced3', 53: '#7b3bb0', 54: '#8fd0ff', 74: '#9aa3ab', 78: '#e3e9ef', 79: '#ffc94a',
  80: '#d7dde2', 82: '#8b949c', 83: '#c9a8d8', 92: '#7b8a5a',
};

const TILE = 2;
const DEPTH = 0.42;
const EDGE_GLOW = 0.55;

function makeEnvTexture() {
  const c = document.createElement('canvas');
  c.width = 512;
  c.height = 256;
  const ctx = c.getContext('2d');

  const g = ctx.createLinearGradient(0, 0, 0, 256);
  g.addColorStop(0, '#08121c');
  g.addColorStop(0.42, '#123341');
  g.addColorStop(0.5, '#1d5668');
  g.addColorStop(0.56, '#0a1a24');
  g.addColorStop(1, '#04070a');
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, 512, 256);

  const blob = (x, y, r, col) => {
    const rg = ctx.createRadialGradient(x, y, 0, x, y, r);
    rg.addColorStop(0, col);
    rg.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = rg;
    ctx.fillRect(x - r, y - r, r * 2, r * 2);
  };
  blob(120, 84, 96, 'rgba(170,235,255,0.95)');
  blob(392, 58, 74, 'rgba(255,242,220,0.8)');
  blob(300, 190, 130, 'rgba(26,96,128,0.55)');

  const tex = new THREE.CanvasTexture(c);
  tex.mapping = THREE.EquirectangularReflectionMapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function makeGlowTexture() {
  const c = document.createElement('canvas');
  c.width = 256;
  c.height = 256;
  const ctx = c.getContext('2d');
  const rg = ctx.createRadialGradient(128, 128, 0, 128, 128, 128);
  rg.addColorStop(0, 'rgba(255,255,255,1)');
  rg.addColorStop(0.32, 'rgba(255,255,255,0.5)');
  rg.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = rg;
  ctx.fillRect(0, 0, 256, 256);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function roundedSlab(w, h, r, depth) {
  const s = new THREE.Shape();
  const x = w / 2;
  const y = h / 2;
  s.moveTo(-x + r, -y);
  s.lineTo(x - r, -y);
  s.quadraticCurveTo(x, -y, x, -y + r);
  s.lineTo(x, y - r);
  s.quadraticCurveTo(x, y, x - r, y);
  s.lineTo(-x + r, y);
  s.quadraticCurveTo(-x, y, -x, y - r);
  s.lineTo(-x, -y + r);
  s.quadraticCurveTo(-x, -y, -x + r, -y);
  const geo = new THREE.ExtrudeGeometry(s, {
    depth,
    bevelEnabled: true,
    bevelThickness: 0.055,
    bevelSize: 0.055,
    bevelSegments: 2,
    curveSegments: 6,
  });
  geo.center();
  return geo;
}

function makeLabel(el) {
  const S = 256;
  const c = document.createElement('canvas');
  c.width = S;
  c.height = S;
  const ctx = c.getContext('2d');
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.shadowColor = 'rgba(0,0,0,0.72)';
  ctx.shadowBlur = 10;

  ctx.fillStyle = 'rgba(255,255,255,0.6)';
  ctx.font = '600 24px "JetBrains Mono", ui-monospace, monospace';
  ctx.fillText(String(el.Z), S / 2, S * 0.2);

  ctx.fillStyle = '#ffffff';
  ctx.font = '700 104px Inter, ui-sans-serif, system-ui, sans-serif';
  ctx.fillText(el.symbol, S / 2, S * 0.5);

  ctx.fillStyle = 'rgba(255,255,255,0.78)';
  ctx.font = '500 21px Inter, ui-sans-serif, system-ui, sans-serif';
  const nm = el.name.length > 13 ? `${el.name.slice(0, 12)}…` : el.name;
  ctx.fillText(nm, S / 2, S * 0.8);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.minFilter = THREE.LinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.generateMipmaps = false;

  const sprite = new THREE.Sprite(
    new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false })
  );
  sprite.scale.set(TILE * 0.96, TILE * 0.96, 1);
  sprite.position.set(0, 0, DEPTH / 2 + 0.14);
  sprite.renderOrder = 3;
  return sprite;
}

// Faint axis marks: group numbers along the top, period numbers down the side
function makeAxisLabel(text) {
  const c = document.createElement('canvas');
  c.width = 128;
  c.height = 64;
  const ctx = c.getContext('2d');
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillStyle = 'rgba(150,178,198,0.8)';
  ctx.font = '600 46px "JetBrains Mono", ui-monospace, monospace';
  ctx.fillText(text, 64, 34);

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.minFilter = THREE.LinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.generateMipmaps = false;

  const sprite = new THREE.Sprite(
    new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, opacity: 0.75 })
  );
  sprite.scale.set(1.15, 0.58, 1);
  sprite.renderOrder = 2;
  return sprite;
}

export default function PeriodicScene({ selectedZ = [], onSelect, apiRef }) {
  const containerRef = useRef(null);
  const [failed, setFailed] = useState(false);
  const onSelectRef = useRef(onSelect);
  onSelectRef.current = onSelect;
  const stateRef = useRef({ meshes: [] });

  useEffect(() => {
    const { meshes } = stateRef.current;
    if (!meshes || !meshes.length) return;
    meshes.forEach((m) => {
      m.userData.sel = selectedZ.includes(m.userData.z);
    });
  }, [selectedZ]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x04070d, 0.0105);

    const camera = new THREE.PerspectiveCamera(42, 1, 0.1, 1400);

    let renderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    } catch (err) {
      setFailed(true);
      return;
    }
    const maxDpr = Math.min(window.devicePixelRatio || 1, 1.75);
    renderer.setPixelRatio(maxDpr);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    const canvasEl = renderer.domElement;
    canvasEl.style.display = 'block';
    canvasEl.style.cursor = 'grab';
    canvasEl.style.touchAction = 'none';
    container.appendChild(canvasEl);

    // Bloom: the emissive bevels and labels glow like a lit instrument panel
    const composer = new EffectComposer(renderer);
    composer.setPixelRatio(maxDpr);
    composer.addPass(new RenderPass(scene, camera));
    const bloom = new UnrealBloomPass(new THREE.Vector2(1, 1), 0.46, 0.62, 0.88);
    composer.addPass(bloom);
    composer.addPass(new OutputPass());

    // Image-based lighting: this is what makes the metals read as metal
    const pmrem = new THREE.PMREMGenerator(renderer);
    pmrem.compileEquirectangularShader();
    const envSrc = makeEnvTexture();
    const envRT = pmrem.fromEquirectangular(envSrc);
    scene.environment = envRT.texture;

    scene.add(new THREE.HemisphereLight(0xa8dcff, 0x05090f, 0.4));

    const key = new THREE.DirectionalLight(0xfff4e6, 1.5);
    key.position.set(16, 26, 26);
    scene.add(key);

    const rim = new THREE.DirectionalLight(0x64d6ff, 1.05);
    rim.position.set(-24, 6, -16);
    scene.add(rim);

    const under = new THREE.DirectionalLight(0x2a6f8f, 0.45);
    under.position.set(0, -18, 12);
    scene.add(under);

    // Backdrop haze + dust
    const glowTex = makeGlowTexture();
    const backdrop = new THREE.Mesh(
      new THREE.PlaneGeometry(96, 54),
      new THREE.MeshBasicMaterial({
        map: glowTex,
        color: 0x0d3b52,
        transparent: true,
        opacity: 0.5,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    );
    backdrop.position.set(0, -1, -14);
    scene.add(backdrop);

    const dustCount = 380;
    const dustPos = new Float32Array(dustCount * 3);
    for (let i = 0; i < dustCount; i++) {
      const r = 70 + Math.random() * 120;
      const th = Math.random() * Math.PI * 2;
      const ph = Math.acos(2 * Math.random() - 1);
      dustPos[i * 3] = r * Math.sin(ph) * Math.cos(th);
      dustPos[i * 3 + 1] = r * Math.sin(ph) * Math.sin(th);
      dustPos[i * 3 + 2] = r * Math.cos(ph);
    }
    const dustGeo = new THREE.BufferGeometry();
    dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPos, 3));
    const dustMat = new THREE.PointsMaterial({
      color: 0x7fc6ff,
      size: 0.7,
      transparent: true,
      opacity: 0.3,
      depthWrite: false,
    });
    const dust = new THREE.Points(dustGeo, dustMat);
    scene.add(dust);

    // Tiles
    const slab = roundedSlab(TILE, TILE, 0.24, DEPTH);
    const haloGeo = new THREE.PlaneGeometry(TILE * 1.9, TILE * 1.9);
    const grey = new THREE.Color('#9aa6b2');
    const meshes = [];

    ELEMENTS.forEach((el) => {
      const { x, y } = layoutFor(el);
      const phys = PHYS[el.cat] || PHYS.transition;
      const fam = CATEGORIES[el.cat]?.color || '#7dd3fc';

      const base = new THREE.Color(REAL_COLOR[el.Z] || fam);
      if (phys.desat) base.lerp(grey, phys.desat);

      // Face = the real substance; bevel edge = the family colour, lit like an indicator
      const faceMat = new THREE.MeshStandardMaterial({
        color: base,
        metalness: phys.metal,
        roughness: phys.rough,
        emissive: base,
        emissiveIntensity: phys.emis,
        envMapIntensity: 1.3,
      });
      if (phys.glass) {
        faceMat.transparent = true;
        faceMat.opacity = 0.74;
        faceMat.depthWrite = false;
      }

      const edgeMat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(fam),
        emissive: new THREE.Color(fam),
        emissiveIntensity: EDGE_GLOW,
        metalness: 0.5,
        roughness: 0.35,
        envMapIntensity: 1.1,
      });

      const mesh = new THREE.Mesh(slab, [faceMat, edgeMat]);
      mesh.position.set(x, y, 0);
      mesh.rotation.y = -(x / 17) * 0.26;
      mesh.rotation.x = 0.015;

      const haloMat = new THREE.MeshBasicMaterial({
        map: glowTex,
        color: new THREE.Color(fam),
        transparent: true,
        opacity: 0,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      });
      const halo = new THREE.Mesh(haloGeo, haloMat);
      halo.position.set(0, 0, -0.5);
      halo.renderOrder = 1;
      mesh.add(halo);

      mesh.add(makeLabel(el));

      mesh.userData = {
        z: el.Z,
        home: new THREE.Vector3(x, y, 0),
        vx: 0, vy: 0, vz: 0,
        spinX: 0, spinY: 0,
        baseRotX: mesh.rotation.x,
        baseRotY: mesh.rotation.y,
        lift: 0,
        emis0: phys.emis,
        faceMat,
        edgeMat,
        sel: false,
        hover: false,
        halo,
        phase: Math.random() * Math.PI * 2,
      };

      scene.add(mesh);
      meshes.push(mesh);
    });
    stateRef.current.meshes = meshes;

    // Axis marks make the floating lattice read as a periodic table
    const axisSprites = [];
    const topY = layoutFor({ group: 1, period: 1 }).y + 1.9;
    const leftX = layoutFor({ group: 1, period: 1 }).x - 1.9;
    for (let g = 1; g <= 18; g++) {
      const s = makeAxisLabel(String(g));
      s.position.set(layoutFor({ group: g, period: 1 }).x, topY, -0.8);
      scene.add(s);
      axisSprites.push(s);
    }
    for (let p = 1; p <= 7; p++) {
      const s = makeAxisLabel(String(p));
      s.position.set(leftX, layoutFor({ group: 1, period: p }).y, -0.8);
      scene.add(s);
      axisSprites.push(s);
    }
    [
      { text: '57–71', y: layoutFor({ group: 3, period: 8 }).y },
      { text: '89–103', y: layoutFor({ group: 3, period: 9 }).y },
    ].forEach(({ text, y }) => {
      const s = makeAxisLabel(text);
      s.scale.set(2.5, 0.58, 1);
      s.position.set(leftX - 0.55, y, -0.8);
      scene.add(s);
      axisSprites.push(s);
    });

    // Orbit controls
    const target = new THREE.Vector3(0, -1.0, 0);
    // Cinematic entry: start wide and off-axis, then ease into the lab's front-on view
    let radius = 78, theta = -0.64, phi = 1.46;
    let radiusT = 44, thetaT = 0, phiT = 1.31;
    const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

    let raf = 0;
    let downX = 0, downY = 0, dragging = false, moved = 0, hovered = null;

    const ray = new THREE.Raycaster();
    const ndc = new THREE.Vector2();

    const pickAt = (clientX, clientY) => {
      const r = canvasEl.getBoundingClientRect();
      ndc.x = ((clientX - r.left) / r.width) * 2 - 1;
      ndc.y = -((clientY - r.top) / r.height) * 2 + 1;
      ray.setFromCamera(ndc, camera);
      const hits = ray.intersectObjects(meshes, false);
      return hits.length ? hits[0].object : null;
    };

    const onPointerDown = (e) => {
      dragging = true;
      moved = 0;
      downX = e.clientX;
      downY = e.clientY;
      canvasEl.style.cursor = 'grabbing';
      try { canvasEl.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    };

    const onPointerMove = (e) => {
      if (dragging) {
        const dx = e.clientX - downX;
        const dy = e.clientY - downY;
        downX = e.clientX;
        downY = e.clientY;
        moved += Math.abs(dx) + Math.abs(dy);
        thetaT -= dx * 0.006;
        phiT = clamp(phiT + dy * 0.006, 0.42, Math.PI - 0.42);
      } else {
        const hit = pickAt(e.clientX, e.clientY);
        if (hit !== hovered) {
          if (hovered) hovered.userData.hover = false;
          hovered = hit;
          if (hovered) hovered.userData.hover = true;
        }
        canvasEl.style.cursor = hit ? 'pointer' : 'grab';
      }
    };

    const onPointerUp = (e) => {
      dragging = false;
      canvasEl.style.cursor = 'grab';
      if (moved < 6) {
        const hit = pickAt(e.clientX, e.clientY);
        if (hit && onSelectRef.current) onSelectRef.current(hit.userData.z);
      }
    };

    const onWheel = (e) => {
      e.preventDefault();
      radiusT = clamp(radiusT * (1 + e.deltaY * 0.0012), 20, 110);
    };

    canvasEl.addEventListener('pointerdown', onPointerDown);
    canvasEl.addEventListener('pointermove', onPointerMove);
    canvasEl.addEventListener('pointerup', onPointerUp);
    canvasEl.addEventListener('wheel', onWheel, { passive: false });

    const resize = () => {
      const w = container.clientWidth || 1;
      const h = container.clientHeight || 1;
      renderer.setSize(w, h);
      composer.setSize(w, h);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(container);

    const kick = (m, power) => {
      const u = m.userData;
      u.vz = power * (0.8 + Math.random() * 0.6);
      u.vx = (Math.random() - 0.5) * power * 0.55;
      u.vy = (Math.random() - 0.5) * power * 0.55;
      u.spinX = (Math.random() - 0.5) * power * 0.22;
      u.spinY = (Math.random() - 0.5) * power * 0.22;
    };

    if (apiRef) {
      apiRef.current = {
        blast(z) {
          const m = meshes.find((x) => x.userData.z === z);
          if (m) kick(m, 22);
        },
        shockwave() {
          meshes.forEach((m) => kick(m, 9 + Math.random() * 10));
        },
        resetView() {
          thetaT = 0;
          phiT = 1.31;
          radiusT = 44;
        },
      };
    }

    const clock = new THREE.Clock();
    const k = 52, damp = 6.2;
    let elapsed = 0;

    const animate = () => {
      const dt = Math.min(clock.getDelta(), 0.04);
      elapsed += dt;

      theta += (thetaT - theta) * 0.14;
      phi += (phiT - phi) * 0.14;
      radius += (radiusT - radius) * 0.14;

      camera.position.set(
        radius * Math.sin(phi) * Math.sin(theta) + target.x,
        radius * Math.cos(phi) + target.y,
        radius * Math.sin(phi) * Math.cos(theta) + target.z
      );
      camera.lookAt(target);

      for (let i = 0; i < meshes.length; i++) {
        const m = meshes[i];
        const u = m.userData;

        const liftTarget = (u.sel ? 0.45 : 0) + (u.hover ? 0.8 : 0);
        u.lift += (liftTarget - u.lift) * 0.16;

        // Idle breathing: a slow vertical drift so the lattice never looks frozen
        const homeZ = u.home.z + u.lift + Math.sin(elapsed * 0.85 + u.phase) * 0.045;
        const dx = m.position.x - u.home.x;
        const dy = m.position.y - u.home.y;
        const dz = m.position.z - homeZ;
        const moving =
          Math.abs(u.vx) + Math.abs(u.vy) + Math.abs(u.vz) > 0.0006 ||
          dx * dx + dy * dy + dz * dz > 0.0006;

        if (moving) {
          u.vx += (-k * dx - damp * u.vx) * dt;
          u.vy += (-k * dy - damp * u.vy) * dt;
          u.vz += (-k * dz - damp * u.vz) * dt;
          m.position.x += u.vx * dt;
          m.position.y += u.vy * dt;
          m.position.z += u.vz * dt;
          m.rotation.x += u.spinX * dt;
          m.rotation.y += u.spinY * dt;
          u.spinX *= 0.995;
          u.spinY *= 0.995;
        } else {
          m.rotation.x += (u.baseRotX - m.rotation.x) * 0.06;
          m.rotation.y += (u.baseRotY - m.rotation.y) * 0.06;
          m.position.z = homeZ;
        }

        const faceTarget = u.emis0 + (u.sel ? 0.5 : 0) + (u.hover ? 0.2 : 0);
        u.faceMat.emissiveIntensity += (faceTarget - u.faceMat.emissiveIntensity) * 0.12;

        const edgeTarget = EDGE_GLOW + (u.sel ? 1.1 : 0) + (u.hover ? 0.45 : 0);
        u.edgeMat.emissiveIntensity += (edgeTarget - u.edgeMat.emissiveIntensity) * 0.12;

        const sTarget = u.sel || u.hover ? 1.045 : 1;
        const s = m.scale.x + (sTarget - m.scale.x) * 0.14;
        m.scale.set(s, s, s);

        const haloTarget = u.sel ? 0.85 : u.hover ? 0.3 : 0;
        u.halo.material.opacity += (haloTarget - u.halo.material.opacity) * 0.12;
      }

      dust.rotation.y += dt * 0.006;
      composer.render();
      raf = requestAnimationFrame(animate);
    };
    animate();

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      canvasEl.removeEventListener('pointerdown', onPointerDown);
      canvasEl.removeEventListener('pointermove', onPointerMove);
      canvasEl.removeEventListener('pointerup', onPointerUp);
      canvasEl.removeEventListener('wheel', onWheel);

      axisSprites.forEach((s) => {
        s.material.map?.dispose();
        s.material.dispose();
      });
      meshes.forEach((m) => {
        m.userData.halo.material.dispose();
        m.children.forEach((ch) => {
          if (ch.isSprite) {
            if (ch.material.map) ch.material.map.dispose();
            ch.material.dispose();
          }
        });
        m.userData.faceMat.dispose();
        m.userData.edgeMat.dispose();
      });
      slab.dispose();
      haloGeo.dispose();
      dustGeo.dispose();
      dustMat.dispose();
      glowTex.dispose();
      envRT.dispose();
      envSrc.dispose();
      pmrem.dispose();
      backdrop.geometry.dispose();
      backdrop.material.dispose();
      stateRef.current.meshes = [];
      bloom.dispose?.();
      composer.dispose?.();
      renderer.dispose();
      if (canvasEl.parentNode) canvasEl.parentNode.removeChild(canvasEl);
    };
  }, [apiRef]);

  if (failed) {
    return (
      <div className="absolute inset-0 grid place-items-center px-8 text-center">
        <p className="max-w-sm text-xs leading-relaxed text-muted-foreground">
          This browser could not start WebGL, so the 3D lattice cannot be drawn. The sandbox and the
          lexicon run without it.
        </p>
      </div>
    );
  }

  return <div ref={containerRef} className="absolute inset-0 h-full w-full" />;
}