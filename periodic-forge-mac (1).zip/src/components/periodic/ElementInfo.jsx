import { CATEGORIES, NOTE } from '@/data/elements';
import { electronConfiguration, blockOf } from '@/data/atom';
import { statesOf } from '@/data/reactions';
import { classifyBond, BONDS } from '@/data/bonds';

function Row({ label, value }) {
  return (
    <div className="flex items-baseline justify-between gap-3 border-b border-border/40 py-1 last:border-b-0">
      <span className="type-tech text-[10px] uppercase tracking-wider text-muted-foreground/80">{label}</span>
      <span className="type-tech text-[11px] font-medium text-foreground">{value}</span>
    </div>
  );
}

export default function ElementInfo({ el, peer }) {
  if (!el) {
    return (
      <div className="rounded-xl border border-dashed border-border bg-secondary/20 px-3 py-4 text-center">
        <p className="text-[11px] leading-relaxed text-muted-foreground">
          Select an element in the table to inspect it.
        </p>
      </div>
    );
  }

  const cat = CATEGORIES[el.cat];
  const states = statesOf(el);
  const bond = peer ? classifyBond(el, peer) : null;
  const delta =
    peer && el.en != null && peer.en != null ? Math.abs(el.en - peer.en) : null;

  return (
    <div className="overflow-hidden rounded-xl border border-border bg-secondary/30">
      <div
        className="flex items-center gap-3 border-b border-border/60 px-3 py-2.5"
        style={{ background: `linear-gradient(120deg, ${cat.color}1f, transparent 70%)` }}
      >
        <div
          className="grid h-12 w-12 shrink-0 place-items-center rounded-lg border"
          style={{ borderColor: `${cat.color}66`, background: `${cat.color}14` }}
        >
          <span className="text-xl font-bold leading-none" style={{ color: cat.color }}>
            {el.symbol}
          </span>
        </div>
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold leading-tight text-foreground">{el.name}</p>
          <p className="type-tech text-[10px] uppercase tracking-wider" style={{ color: cat.color }}>
            {cat.label}
          </p>
        </div>
        <span className="ml-auto type-tech text-[10px] text-muted-foreground/70">{el.Z}</span>
      </div>

      <div className="px-3 py-1.5">
        <Row label="Atomic mass" value={`${el.mass} u`} />
        <Row label="State · 20 °C" value={el.state} />
        <Row label="Group · period" value={`${el.group} · ${el.period}`} />
        <Row label="Block" value={`${blockOf(el.Z)}-block`} />
        <Row label="Electronegativity" value={el.en != null ? el.en.toFixed(2) : '—'} />
      </div>

      <div className="border-t border-border/60 px-3 py-2">
        <p className="type-tech text-[9px] uppercase tracking-widest text-muted-foreground/70">
          Oxidation states
        </p>
        <div className="mt-1 flex flex-wrap gap-1">
          {states.length ? (
            states.map((s) => (
              <span
                key={s}
                className="rounded border border-border bg-background/50 px-1.5 py-0.5 type-tech text-[10px] text-foreground/90"
              >
                {s}
              </span>
            ))
          ) : (
            <span className="text-[10px] text-muted-foreground">none common</span>
          )}
        </div>
        <p className="mt-2 type-tech text-[10px] leading-relaxed text-muted-foreground">
          {electronConfiguration(el.Z)}
        </p>
      </div>

      {peer && (
        <div className="flex items-center justify-between gap-2 border-t border-border/60 px-3 py-2">
          <span className="type-tech text-[9px] uppercase tracking-widest text-muted-foreground/70">
            ΔEN with {peer.symbol}
          </span>
          <span className="flex items-center gap-1.5">
            <span className="type-tech text-[11px] text-foreground">{delta != null ? delta.toFixed(2) : '—'}</span>
            {bond && (
              <span
                className="rounded-full px-1.5 py-0.5 text-[9px] uppercase tracking-wide"
                style={{ color: BONDS[bond].color, background: `${BONDS[bond].color}1f` }}
              >
                {BONDS[bond].label}
              </span>
            )}
          </span>
        </div>
      )}

      {NOTE[el.Z] && (
        <p className="border-t border-border/60 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
          {NOTE[el.Z]}
        </p>
      )}
    </div>
  );
}