import { Flame, Wind, Droplets, Zap, RotateCcw, X, Sparkles, Beaker } from 'lucide-react';
import { CATEGORIES } from '@/data/elements';
import ElementInfo from '@/components/periodic/ElementInfo';
import { classifyBond, BONDS } from '@/data/bonds';

const ENERGY_STYLE = {
  violent: 'text-red-300 border-red-500/40 bg-red-500/[0.09]',
  strong: 'text-orange-200 border-orange-500/40 bg-orange-500/[0.09]',
  moderate: 'text-amber-200 border-amber-500/40 bg-amber-500/[0.09]',
  mild: 'text-emerald-200 border-emerald-500/40 bg-emerald-500/[0.09]',
  none: 'text-muted-foreground border-border bg-muted/20',
};

const ENERGY_LABEL = {
  violent: 'Violent · explosive',
  strong: 'Strongly exothermic',
  moderate: 'Moderate',
  mild: 'Mild · slow',
  none: 'No reaction',
};

const ENERGY_STEP = { none: 0, mild: 1, moderate: 2, strong: 3, violent: 4 };

const ENERGY_BAR = {
  violent: 'bg-red-400',
  strong: 'bg-orange-400',
  moderate: 'bg-amber-300',
  mild: 'bg-emerald-400',
  none: 'bg-border',
};

function ToolButton({ onClick, disabled, icon: Icon, children }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className="flex items-center justify-center gap-1.5 rounded-lg border border-border bg-secondary/40 px-2 py-2 text-[11px] font-medium text-foreground/90 transition hover:border-primary/40 hover:bg-secondary disabled:cursor-not-allowed disabled:opacity-35"
    >
      <Icon size={13} /> {children}
    </button>
  );
}

const QUICK = [
  { label: 'Na + Cl₂', note: 'table salt', a: 11, b: 17 },
  { label: 'Mg + O₂', note: 'white light', a: 12, b: 8 },
  { label: 'Fe + S', note: 'glowing fusion', a: 26, b: 16 },
  { label: 'H₂ + O₂', note: 'detonation', a: 1, b: 8 },
];

function Slot({ el, label, onRemove }) {
  const cat = el ? CATEGORIES[el.cat] : null;
  return (
    <div
      className={`relative grid h-[78px] place-items-center rounded-lg border ${
        el ? 'bg-background/40' : 'border-dashed border-border bg-secondary/20'
      }`}
      style={el ? { borderColor: `${cat.color}59` } : undefined}
    >
      {el ? (
        <>
          <button
            onClick={() => onRemove(el.Z)}
            className="absolute right-1 top-1 rounded p-0.5 text-muted-foreground transition hover:text-foreground"
          >
            <X size={11} />
          </button>
          <div className="flex flex-col items-center">
            <span className="text-xl font-bold leading-none" style={{ color: cat.color }}>
              {el.symbol}
            </span>
            <span className="mt-1 max-w-[92px] truncate text-[10px] text-muted-foreground">{el.name}</span>
            <span className="type-tech text-[9px] text-muted-foreground/60">{el.mass} u</span>
          </div>
        </>
      ) : (
        <span className="type-tech text-[10px] uppercase tracking-widest text-muted-foreground/70">
          Slot {label}
        </span>
      )}
    </div>
  );
}

export default function ControlPanel({
  sel, info, result, log, highEnergy, setHighEnergy,
  onRemove, onClear, onReact, onAir, onWater, onHeat, onImpact, onQuickPick,
}) {
  const canReact = sel.length === 2;
  const bond = sel.length === 2 ? classifyBond(sel[0], sel[1]) : null;
  const bondMeta = bond ? BONDS[bond] : null;
  const level = ENERGY_STEP[result?.energy] ?? 0;

  return (
    <div className="flex h-full flex-col overflow-y-auto">
      <div className="sticky top-0 z-10 border-b border-border bg-card/95 px-4 py-3 backdrop-blur-xl">
        <div className="flex items-center justify-between">
          <h2 className="type-display text-[13px] tracking-[0.18em] text-foreground">REACTION CHAMBER</h2>
          <span className="type-tech text-[9px] uppercase tracking-widest text-muted-foreground/70">
            {sel.length}/2 loaded
          </span>
        </div>
        <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">
          Load two elements to combine them, or probe one against air, water, heat or impact.
        </p>
      </div>

      <div className="flex flex-col gap-3 p-4">
        <div className="grid grid-cols-2 gap-2">
          <Slot el={sel[0]} label="A" onRemove={onRemove} />
          <Slot el={sel[1]} label="B" onRemove={onRemove} />
        </div>

        {bondMeta && (
          <div className="flex items-center justify-between rounded-lg border border-border/70 bg-secondary/25 px-2.5 py-1.5">
            <span className="type-tech text-[9px] uppercase tracking-widest text-muted-foreground/70">
              Predicted bond
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: bondMeta.color }} />
              <span className="text-[10px]" style={{ color: bondMeta.color }}>{bondMeta.label}</span>
            </span>
          </div>
        )}

        {!sel.length && (
          <div>
            <p className="type-tech text-[9px] uppercase tracking-widest text-muted-foreground/70">
              Quick starts
            </p>
            <div className="mt-1.5 grid grid-cols-2 gap-1.5">
              {QUICK.map((q) => (
                <button
                  key={q.label}
                  onClick={() => onQuickPick(q.a, q.b)}
                  className="rounded-lg border border-border bg-secondary/25 px-2 py-1.5 text-left transition hover:border-primary/40 hover:bg-secondary/60"
                >
                  <span className="block type-tech text-[10px] font-semibold text-foreground">{q.label}</span>
                  <span className="block text-[9px] text-muted-foreground">{q.note}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        <button
          onClick={onReact}
          disabled={!canReact}
          className="flex items-center justify-center gap-2 rounded-lg bg-primary px-3 py-2.5 text-sm font-semibold text-primary-foreground shadow-[0_0_24px_-8px_hsl(var(--primary))] transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-35 disabled:shadow-none"
        >
          <Sparkles size={14} /> React A + B
        </button>

        <div className="grid grid-cols-2 gap-2">
          <ToolButton onClick={onAir} disabled={!sel.length} icon={Wind}>Air</ToolButton>
          <ToolButton onClick={onWater} disabled={!sel.length} icon={Droplets}>Water</ToolButton>
          <ToolButton onClick={onHeat} disabled={!sel.length} icon={Flame}>Heat</ToolButton>
          <ToolButton onClick={onImpact} disabled={!sel.length} icon={Zap}>Impact</ToolButton>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setHighEnergy(!highEnergy)}
            className={`flex flex-1 items-center justify-between rounded-lg border px-2.5 py-2 transition ${
              highEnergy
                ? 'border-amber-500/50 bg-amber-500/10 text-amber-200'
                : 'border-border bg-secondary/30 text-muted-foreground'
            }`}
          >
            <span className="text-[11px] font-medium">High energy</span>
            <span
              className={`flex h-3.5 w-7 items-center rounded-full p-0.5 transition ${
                highEnergy ? 'bg-amber-500/70' : 'bg-border'
              }`}
            >
              <span
                className={`h-2.5 w-2.5 rounded-full bg-background transition ${
                  highEnergy ? 'translate-x-3.5' : 'translate-x-0'
                }`}
              />
            </span>
          </button>
          <button
            onClick={onClear}
            disabled={!sel.length && !result}
            className="grid h-[34px] w-[34px] place-items-center rounded-lg border border-border bg-secondary/30 text-muted-foreground transition hover:text-foreground disabled:opacity-35"
            title="Reset chamber"
            aria-label="Reset chamber"
          >
            <RotateCcw size={13} />
          </button>
        </div>

        {result && (
          <div className={`rounded-xl border p-3 ${ENERGY_STYLE[result.energy] || ENERGY_STYLE.none}`}>
            <div className="flex items-center justify-between gap-2">
              <p className="type-tech text-[9px] uppercase tracking-widest opacity-85">
                {ENERGY_LABEL[result.energy] || 'Outcome'}
              </p>
              <div className="flex gap-0.5">
                {[0, 1, 2, 3].map((i) => (
                  <span
                    key={i}
                    className={`h-1.5 w-3 rounded-sm ${
                      i < level ? ENERGY_BAR[result.energy] : 'bg-foreground/10'
                    }`}
                  />
                ))}
              </div>
            </div>
            <p className="mt-1.5 break-words font-mono text-[13px] font-semibold leading-snug text-foreground">
              {result.equation}
            </p>
            <p className="mt-1 text-[11px] font-medium opacity-90">{result.product}</p>
            <p className="mt-1.5 text-[11px] leading-relaxed text-muted-foreground">{result.description}</p>
          </div>
        )}

        <ElementInfo el={info} peer={sel.length === 2 ? sel.find((e) => e.Z !== info?.Z) : null} />

        {log.length > 0 && (
          <div>
            <div className="mb-1.5 flex items-center gap-2">
              <p className="type-tech text-[9px] uppercase tracking-widest text-muted-foreground/70">
                Recent outcomes
              </p>
              <span className="h-px flex-1 bg-border/60" />
            </div>
            <ul className="space-y-1">
              {log.map((l) => (
                <li
                  key={l.id}
                  className="flex items-center justify-between gap-2 rounded-md border border-border/50 bg-secondary/20 px-2 py-1.5"
                >
                  <span className="truncate type-tech text-[10px] text-muted-foreground">{l.equation}</span>
                  <span
                    className={`shrink-0 text-[9px] uppercase tracking-wide ${
                      l.ok ? 'text-emerald-400' : 'text-muted-foreground/70'
                    }`}
                  >
                    {l.ok ? 'reacted' : 'inert'}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        )}

        <p className="flex items-start gap-1.5 pt-1 text-[10px] leading-relaxed text-muted-foreground/60">
          <Beaker size={11} className="mt-0.5 shrink-0" />
          Oxidation-state engine with curated exceptions. Thermodynamics are qualitative, not quantum.
        </p>
      </div>
    </div>
  );
}