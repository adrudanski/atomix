import { MonitorDown } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

const STEPS = [
  {
    app: 'Safari on macOS',
    how: 'Choose File → Add to Dock. Periodic Forge then opens in its own window with its own Dock icon and no browser chrome.',
  },
  {
    app: 'Chrome or Edge',
    how: 'Click the install icon at the right end of the address bar — or the ⋮ menu → Cast, save and share → Install page as app.',
  },
  {
    app: 'iPhone or iPad',
    how: 'Open the Share menu and choose Add to Home Screen.',
  },
];

export default function InstallToDock() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <button
          aria-label="Install as a desktop app"
          className="inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary/40 px-2.5 py-1.5 type-tech text-[10px] uppercase tracking-widest text-muted-foreground transition hover:border-primary/40 hover:text-foreground"
        >
          <MonitorDown size={11} />
          <span className="hidden lg:inline">Dock</span>
        </button>
      </DialogTrigger>
      <DialogContent className="border-border bg-card sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="type-display text-base font-bold text-foreground">
            Install as a desktop app
          </DialogTitle>
          <DialogDescription className="text-xs leading-relaxed text-muted-foreground">
            The lab runs in its own window with its own Dock icon, and keeps the model you connect once in LM Studio.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-2 pt-1">
          {STEPS.map(({ app, how }) => (
            <div key={app} className="rounded-lg border border-border bg-secondary/30 px-3 py-2">
              <p className="type-tech text-[10px] uppercase tracking-widest text-primary">{app}</p>
              <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">{how}</p>
            </div>
          ))}
          <p className="pt-1 text-[10px] leading-relaxed text-muted-foreground/80">
            A packaged .dmg still has to be built outside Base44 — the dock-installed app is the same code, offline-ready.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}