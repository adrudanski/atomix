import { Link } from 'react-router-dom';
import { Boxes, FlaskConical, Library } from 'lucide-react';
import InstallToDock from '@/components/InstallToDock';
import { STANDALONE } from '@/lib/standalone';

const MODES = [
  { to: '/', key: 'table', label: 'Table', icon: Boxes },
  { to: '/sandbox', key: 'sandbox', label: 'Sandbox', icon: FlaskConical },
  { to: '/lexicon', key: 'lexicon', label: 'Lexicon', icon: Library },
];

export default function ModeNav({ current }) {
  return (
    <div className="flex shrink-0 items-center gap-1.5">
      <nav className="flex shrink-0 items-center gap-0.5 rounded-full border border-border bg-secondary/40 p-0.5">
      {MODES.map(({ to, key, label, icon: Icon }) => {
        const active = current === key;
        return (
          <Link
            key={key}
            to={to}
            aria-current={active ? 'page' : undefined}
            className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1.5 type-tech text-[10px] uppercase tracking-widest transition ${
              active
                ? 'bg-primary/15 text-primary shadow-[inset_0_0_0_1px_hsl(var(--primary)/0.35)]'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Icon size={11} />
            <span className="hidden sm:inline">{label}</span>
          </Link>
        );
      })}
      </nav>
      {/* Already a real Mac app here, so the "install to Dock" help would be misleading. */}
      {!STANDALONE && <InstallToDock />}
    </div>
  );
}