import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Sparkles, Loader2, Send, ShieldCheck, Globe, Play, Cpu } from 'lucide-react';
import AiVerdict from '@/components/sandbox/AiVerdict';
import LocalModelDialog from '@/components/sandbox/LocalModelDialog';
import { askLocal, readLocalModel, shortModelName, subscribeLocalModel } from '@/lib/localModel';
import useOnline from '@/hooks/useOnline';
import { STANDALONE } from '@/lib/standalone';
import { ELEMENTS } from '@/data/elements';
import { RECIPE_LIST } from '@/data/molecules';

const ASK_SCHEMA = {
  type: 'object',
  properties: {
    answer: { type: 'string' },
    equation: { type: 'string' },
    demo: {
      type: 'object',
      properties: {
        show: { type: 'boolean' },
        steps: {
          type: 'array',
          items: {
            type: 'object',
            properties: {
              op: { type: 'string', enum: ['clear', 'add', 'combine', 'heat', 'air', 'water'] },
              symbol: { type: 'string' },
              note: { type: 'string' },
            },
            required: ['op'],
          },
        },
      },
      required: ['show', 'steps'],
    },
  },
  required: ['answer'],
};

const VERIFY_SCHEMA = {
  type: 'object',
  properties: {
    happens: { type: 'boolean' },
    equation: { type: 'string' },
    product: { type: 'string' },
    conditions: { type: 'string' },
    observation: { type: 'string' },
    energy: { type: 'string', enum: ['violent', 'strong', 'moderate', 'mild', 'none'] },
    notes: { type: 'string' },
  },
  required: ['happens', 'equation', 'product', 'energy'],
};

const SUGGESTIONS = [
  'Show sulfuric acid forming',
  'Why does this release heat?',
  'Build copper sulfate in the chamber',
];

const OPS = ['clear', 'add', 'combine', 'heat', 'air', 'water'];
const SYMBOLS = new Set(ELEMENTS.map((e) => e.symbol.toLowerCase()));
const uid = () => Math.random().toString(36).slice(2);

// Keep only steps the chamber can actually execute.
function sanitizeSteps(raw) {
  if (!Array.isArray(raw)) return [];
  return raw
    .slice(0, 12)
    .filter((s) => s && OPS.includes(s.op))
    .filter((s) => s.op !== 'add' || SYMBOLS.has(String(s.symbol || '').toLowerCase()))
    .map((s) => ({ op: s.op, symbol: (s.symbol || '').trim(), note: s.note || '' }));
}

export default function AiLab({ chamber, result, running, onRunDemo }) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(null);
  const [error, setError] = useState('');
  const [messages, setMessages] = useState([]);
  const [verdict, setVerdict] = useState(null);
  const [localCfg, setLocalCfg] = useState(readLocalModel);
  const [modelOpen, setModelOpen] = useState(false);
  const online = useOnline();

  useEffect(() => subscribeLocalModel(setLocalCfg), []);

  const chamberText = chamber.length ? chamber.join(' + ') : 'empty';
  const engineLine = result ? `${result.equation} — ${result.product} (${result.energy})` : 'nothing yet';
  const modelName = localCfg ? shortModelName(localCfg.model) : '';
  const sourceLine = localCfg
    ? 'Answer from your own chemistry knowledge in plain language, 120 words max. You have no web access, so say briefly when something is beyond your certainty.'
    : 'Answer accurately and concisely (120 words max) in plain language, using live web information where useful.';

  // Both engines share one call site: the user's LM Studio model, or the built-in AI.
  const runLLM = (schema, prompt) =>
    localCfg
      ? askLocal({ schema, prompt })
      : base44.integrations.Core.InvokeLLM({
          model: 'gemini_3_flash',
          add_context_from_internet: true,
          response_json_schema: schema,
          prompt,
        });

  // Desktop build: the hosted Base44 AI is not part of the app, so the lab needs a
  // local model. Ask the player to connect one instead of failing silently.
  const needsModel = () => {
    if (!STANDALONE || localCfg) return false;
    setError('Connect your LM Studio model first — the AI lab answers on this Mac.');
    setModelOpen(true);
    return true;
  };

  const play = async (message) => {
    if (!message.steps?.length) return;
    await onRunDemo(message.steps);
  };

  const ask = async (text) => {
    const question = (text || q).trim();
    if (!question || busy || running) return;
    if (needsModel()) return;
    setError('');
    setQ('');
    setMessages((prev) => [...prev, { id: uid(), role: 'user', text: question }]);
    setBusy('ask');
    try {
      const res = await runLLM(ASK_SCHEMA, `You are the chemist operating a virtual reaction sandbox called "Periodic Forge".
Chamber contents: ${chamberText}.
The game engine currently shows: ${engineLine}.

The sandbox is built from element specimens. You can drive it live for the player. Mechanics:
- "add" places one ELEMENT specimen, using its real chemical symbol (H, O, Na, Cl, Fe …).
- "combine" fuses the two most recently placed specimens into a compound; the compound stays in the chamber and can be combined again, which is how multi-element structures are built.
- "heat", "air" and "water" act on the most recently placed element (heat = burn in air, air = room-temperature oxidation, water = react with water).
- Demos always start from an empty chamber, so begin with a "clear" step.
Advanced structures the engine can form from element sets: ${RECIPE_LIST}.
One specimen of each element is enough: the engine fuses an element set straight into its most stable compound, so never repeat the same element to fake stoichiometry.
Example of a valid demo (sulfuric acid): clear, add H, add O, combine (→ H₂O), add S, add O, combine (→ SO₂), combine (H₂O + SO₂ → H₂SO₄).

Player request: "${question}"

${sourceLine}
Give a balanced equation with state symbols when a reaction is involved.
Set demo.show to true ONLY when the player asks you to show, demonstrate, build, simulate, run or play something in the sandbox. Then give a step sequence that really produces the result: at most 10 steps, every "add" step using a valid element symbol, every element mentioned in the sequence present, and only "combine" when two specimens exist. If they are only asking a question, set demo.show false and leave steps empty.
Never invent facts; if something is uncertain, say so briefly.`);
      const steps = sanitizeSteps(res.demo?.steps);
      const message = {
        id: uid(),
        role: 'ai',
        text: res.answer,
        equation: res.equation,
        steps,
      };
      setMessages((prev) => [...prev, message]);
      setBusy(null);
      if (res.demo?.show && steps.length) await play(message);
    } catch (err) {
      setError(
        localCfg
          ? 'Your local model did not answer. Check that LM Studio is still serving it, then try again.'
          : 'The AI lab could not answer just now. Try again in a moment.'
      );
      setBusy(null);
    }
  };

  const verify = async () => {
    if (!chamber.length || busy || running) return;
    if (needsModel()) return;
    setError('');
    setBusy('verify');
    try {
      const res = await runLLM(VERIFY_SCHEMA, `You are a rigorous inorganic chemistry referee for "Periodic Forge", an element reaction game.
Chamber contents: ${chamberText}.
The game engine predicts: ${engineLine}.

Give the most accurate real-world answer for what happens when these substances meet in a laboratory.${localCfg ? ' Use your own chemistry knowledge.' : ' Search the web for current reference data when useful.'}
- equation: balanced, with state symbols, using the most stable realistic product(s).
- happens: false only if there is genuinely no reaction under normal conditions.
- conditions: temperature, pressure, solvent, catalyst or atmosphere needed; otherwise "standard conditions".
- observation: what a player would physically see.
- energy: violent, strong, moderate, mild or none.
- notes: one or two sentences correcting the engine's prediction if it is wrong or oversimplified.`);
      setVerdict(res);
    } catch (err) {
      setError(
        localCfg
          ? 'Your local model did not answer. Check that LM Studio is still serving it, then try again.'
          : 'Could not reach the AI lab. Try again in a moment.'
      );
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="shrink-0 rounded-2xl border border-border bg-card/60">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center gap-2 px-3 py-2.5 text-left"
      >
        <Sparkles size={14} className="shrink-0 text-primary" />
        <span className="type-tech text-[10px] uppercase tracking-widest text-primary">
          Accurate mode
        </span>
        <span
          className={`hidden items-center gap-1 rounded-full border px-2 py-0.5 text-[9px] uppercase tracking-wider sm:inline-flex ${
            localCfg
              ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300'
              : 'border-primary/30 bg-primary/10 text-primary'
          }`}
        >
          {localCfg || STANDALONE ? <Cpu size={9} /> : <Globe size={9} />}
          <span className="max-w-[130px] truncate">
            {localCfg ? `${modelName} · local` : STANDALONE ? 'No model connected' : 'Google AI · live'}
          </span>
        </span>
        <span className="ml-auto text-[10px] text-muted-foreground">{open ? 'hide' : 'ask'}</span>
      </button>

      {open && (
        <div className="space-y-2.5 border-t border-border px-3 pb-3 pt-2.5">
          <button
            onClick={() => setModelOpen(true)}
            className={`inline-flex items-center gap-1.5 rounded-lg border border-dashed px-2.5 py-1.5 text-[10px] transition ${
              localCfg
                ? 'border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/10'
                : 'border-border text-muted-foreground hover:border-primary/40 hover:text-foreground'
            }`}
          >
            <Cpu size={11} />
            {localCfg ? `On-device · ${modelName}` : 'Use my own LM Studio model'}
          </button>

          {(STANDALONE || !online) && !localCfg && (
            <p className="rounded-lg border border-amber-500/30 bg-amber-500/5 px-2.5 py-2 text-[10px] leading-relaxed text-amber-200/90">
              {STANDALONE
                ? 'The AI lab runs on your own model. Start LM Studio, connect it above, and the lab answers right here on this Mac — no internet needed.'
                : 'You are offline. The built-in AI needs a connection — connect your LM Studio model and the lab keeps answering on this Mac.'}
            </p>
          )}

          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={verify}
              disabled={!chamber.length || !!busy || running}
              className="inline-flex items-center gap-1.5 rounded-lg border border-primary/40 bg-primary/10 px-2.5 py-1.5 text-[11px] font-semibold text-primary transition hover:bg-primary/20 disabled:opacity-40"
            >
              {busy === 'verify' ? <Loader2 size={12} className="animate-spin" /> : <ShieldCheck size={12} />}
              Verify this reaction
            </button>
            {SUGGESTIONS.map((s) => (
              <button
                key={s}
                onClick={() => ask(s)}
                disabled={!!busy || running}
                className="rounded-lg border border-border bg-secondary/40 px-2 py-1.5 text-[10px] text-muted-foreground transition hover:text-foreground disabled:opacity-40"
              >
                {s}
              </button>
            ))}
          </div>

          {verdict && <AiVerdict verdict={verdict} />}

          {messages.length > 0 && (
            <div className="max-h-[240px] space-y-2 overflow-y-auto pr-1">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`rounded-lg px-2.5 py-2 text-[11px] leading-relaxed ${
                    m.role === 'user'
                      ? 'ml-6 border border-border bg-secondary/40 text-foreground'
                      : 'mr-6 border border-primary/25 bg-primary/5 text-muted-foreground'
                  }`}
                >
                  {m.text}
                  {m.equation && (
                    <span className="mt-1 block type-tech text-[10px] text-primary">{m.equation}</span>
                  )}
                  {m.role === 'ai' && m.steps?.length > 0 && (
                    <button
                      onClick={() => play(m)}
                      disabled={running}
                      className="mt-1.5 inline-flex items-center gap-1 rounded-md border border-primary/40 bg-primary/10 px-2 py-1 text-[10px] font-semibold text-primary transition hover:bg-primary/20 disabled:opacity-40"
                    >
                      <Play size={9} /> Play in sandbox
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}

          {busy === 'ask' && (
            <p className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
              <Loader2 size={11} className="animate-spin" />{' '}
              {localCfg ? `Asking ${modelName}…` : 'Searching live chemistry data…'}
            </p>
          )}

          {error && <p className="text-[10px] text-destructive">{error}</p>}

          <div className="flex items-center gap-1.5">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && ask()}
              placeholder="Ask, or say “show me…” to run it live…"
              className="h-8 flex-1 rounded-lg border border-border bg-background px-2.5 text-[11px] text-foreground placeholder:text-muted-foreground/70 focus:outline-none focus:ring-1 focus:ring-primary/60"
            />
            <button
              onClick={() => ask()}
              disabled={!q.trim() || !!busy || running}
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-border bg-secondary/50 text-primary transition hover:bg-secondary disabled:opacity-40"
            >
              {busy === 'ask' ? <Loader2 size={13} className="animate-spin" /> : <Send size={13} />}
            </button>
          </div>
        </div>
      )}

      <LocalModelDialog open={modelOpen} onOpenChange={setModelOpen} />
    </div>
  );
}