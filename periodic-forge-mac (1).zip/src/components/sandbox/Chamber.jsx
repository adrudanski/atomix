import { useRef } from 'react';
import Specimen from '@/components/sandbox/Specimen';
import { FlaskConical } from 'lucide-react';

export default function Chamber({ specimens, selectedId, caption, onSelect, onMove, onCombine, onRemove }) {
  const boxRef = useRef(null);
  const dragRef = useRef(null);

  const handleDown = (e, sp) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    const rect = boxRef.current.getBoundingClientRect();
    dragRef.current = {
      id: sp.id,
      dx: e.clientX - rect.left - sp.x * rect.width,
      dy: e.clientY - rect.top - sp.y * rect.height,
    };
    onSelect(sp.id);
  };

  const handleMove = (e) => {
    const d = dragRef.current;
    if (!d) return;
    const rect = boxRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left - d.dx) / rect.width;
    const y = (e.clientY - rect.top - d.dy) / rect.height;
    onMove(d.id, Math.min(0.95, Math.max(0.05, x)), Math.min(0.92, Math.max(0.08, y)));
  };

  const handleUp = () => {
    const d = dragRef.current;
    dragRef.current = null;
    if (!d) return;
    const a = specimens.find((s) => s.id === d.id);
    if (!a) return;
    const rect = boxRef.current.getBoundingClientRect();
    const other = specimens.find((s) => {
      if (s.id === a.id) return false;
      const dx = (s.x - a.x) * rect.width;
      const dy = (s.y - a.y) * rect.height;
      return Math.sqrt(dx * dx + dy * dy) < 62;
    });
    if (other) onCombine(a.id, other.id);
  };

  return (
    <div
      ref={boxRef}
      className="relative min-h-[320px] flex-1 overflow-hidden rounded-2xl border border-border bg-card/50"
    >
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.28]"
        style={{
          backgroundImage:
            'linear-gradient(to right, hsl(var(--border)) 1px, transparent 1px), linear-gradient(to bottom, hsl(var(--border)) 1px, transparent 1px)',
          backgroundSize: '42px 42px',
        }}
      />
      <div
        className="pointer-events-none absolute inset-0"
        style={{ background: 'radial-gradient(circle at 50% 42%, hsl(var(--primary)/0.10), transparent 65%)' }}
      />

      {specimens.map((sp) => (
        <Specimen
          key={sp.id}
          sp={sp}
          selected={selectedId === sp.id}
          onDown={handleDown}
          onMove={handleMove}
          onUp={handleUp}
          onRemove={onRemove}
        />
      ))}

      {!specimens.length && (
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-2 text-center">
          <FlaskConical className="text-muted-foreground/50" size={28} />
          <p className="text-xs font-medium text-muted-foreground">The chamber is empty</p>
          <p className="max-w-[240px] text-[11px] leading-relaxed text-muted-foreground/70">
            Pick elements from the left to place them here, then drag one onto another to react them.
          </p>
        </div>
      )}

      {caption && (
        <div className="pointer-events-none absolute left-1/2 top-3 z-20 -translate-x-1/2 rounded-full border border-primary/40 bg-background/85 px-3 py-1.5 text-[10px] text-primary shadow-lg backdrop-blur">
          {caption}
        </div>
      )}

      <div className="pointer-events-none absolute bottom-2 left-3 type-tech text-[10px] text-muted-foreground/60">
        CHAMBER · {specimens.length} SPECIMEN{specimens.length === 1 ? '' : 'S'}
      </div>
    </div>
  );
}