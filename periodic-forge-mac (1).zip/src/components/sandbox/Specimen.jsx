import { BONDS } from '@/data/bonds';

export default function Specimen({ sp, selected, onDown, onMove, onUp, onRemove }) {
  const c = sp.color;
  const isCompound = sp.kind === 'compound';
  const bond = sp.bond ? BONDS[sp.bond] : null;

  const shell = selected
    ? 'ring-2 ring-primary/80 ring-offset-2 ring-offset-background'
    : 'ring-1 ring-white/10';

  return (
    <div
      className="specimen-pop absolute z-10 -translate-x-1/2 -translate-y-1/2 touch-none select-none"
      style={{ left: `${sp.x * 100}%`, top: `${sp.y * 100}%` }}
      onPointerDown={(e) => onDown(e, sp)}
      onPointerMove={onMove}
      onPointerUp={onUp}
      onPointerCancel={onUp}
      onDoubleClick={() => onRemove(sp.id)}
    >
      <div className="group relative flex flex-col items-center">
        {isCompound ? (
          <div
            className={`grid h-16 w-16 place-items-center rounded-[18px] ${shell}`}
            style={{
              background: `linear-gradient(150deg, #ffffffcc 0%, ${c} 38%, ${c}bb 68%, ${c}66 100%)`,
              boxShadow: `0 10px 26px -10px ${c}dd, inset 0 1px 0 rgba(255,255,255,0.55), inset 0 -10px 18px rgba(0,0,0,0.35)`,
            }}
          >
            <span
              className={`px-0.5 text-center font-bold leading-tight text-background/85 drop-shadow-sm ${
                (sp.formula || '').length > 6
                  ? 'text-[8.5px]'
                  : (sp.formula || '').length > 3
                    ? 'text-[10px]'
                    : 'text-[12px]'
              }`}
            >
              {sp.formula || sp.label}
            </span>
          </div>
        ) : sp.state === 'gas' ? (
          <div className={`relative h-16 w-16 rounded-full ${shell}`}>
            <div
              className="absolute inset-0 rounded-full blur-[7px]"
              style={{ background: `radial-gradient(circle, ${c}8c, transparent 72%)` }}
            />
            <div className="absolute inset-2 rounded-full border" style={{ borderColor: `${c}44`, background: `${c}0f` }} />
            <div className="absolute inset-0 animate-[spin_9s_linear_infinite]">
              <span className="absolute left-1/2 top-1.5 h-1.5 w-1.5 -translate-x-1/2 rounded-full" style={{ background: c }} />
              <span className="absolute bottom-2 left-2 h-1 w-1 rounded-full" style={{ background: c }} />
              <span className="absolute bottom-2 right-2 h-1 w-1 rounded-full" style={{ background: c }} />
            </div>
            <span className="absolute left-4 top-4 h-2 w-2 rounded-full bg-white/25 blur-[1px]" />
          </div>
        ) : sp.state === 'liquid' ? (
          <div
            className={`relative h-14 w-14 rounded-full ${shell}`}
            style={{
              background: `radial-gradient(circle at 34% 26%, #ffffffdd 0%, ${c} 42%, ${c}b3 72%, ${c}5c 100%)`,
              boxShadow: `0 10px 24px -10px ${c}cc, inset 0 -8px 14px rgba(0,0,0,0.4)`,
            }}
          >
            <span className="absolute left-3 top-2.5 h-2.5 w-4 rotate-[-25deg] rounded-full bg-white/70 blur-[1px]" />
          </div>
        ) : (
          <div
            className={`h-14 w-14 rounded-[14px] ${shell}`}
            style={{
              background: `linear-gradient(150deg, ${c} 0%, ${c}cc 42%, ${c}8c 72%, ${c}59 100%)`,
              boxShadow: `0 10px 22px -10px ${c}aa, inset 0 1px 0 rgba(255,255,255,0.5), inset 0 -10px 16px rgba(0,0,0,0.45)`,
            }}
          />
        )}

        <span className="mt-1.5 rounded-md border border-border/60 bg-background/85 px-1.5 py-0.5 type-tech text-[10px] font-semibold text-foreground backdrop-blur">
          {sp.label}
        </span>
        <span className="max-w-[92px] truncate text-center text-[9px] leading-tight text-muted-foreground">
          {sp.name}
        </span>
        {bond && (
          <span
            className="mt-0.5 inline-flex items-center gap-1 rounded-full px-1.5 py-0.5 text-[8px] uppercase tracking-wide"
            style={{ color: bond.color, background: `${bond.color}1f` }}
          >
            <span className="h-1 w-1 rounded-full" style={{ background: bond.color }} />
            {bond.label}
          </span>
        )}

        <button
          onClick={(e) => {
            e.stopPropagation();
            onRemove(sp.id);
          }}
          aria-label={`Remove ${sp.label}`}
          className="absolute -right-1 -top-1 hidden h-4 w-4 items-center justify-center rounded-full border border-border bg-card text-[9px] text-muted-foreground group-hover:flex"
        >
          ×
        </button>
      </div>
    </div>
  );
}