import { Sparkles, Lock } from 'lucide-react';

const TIERS = [
  { at: 2, label: 'Binary pair', note: 'oxide · halide · sulfide' },
  { at: 3, label: 'Polyatomic salt', note: 'nitrate · sulfate · carbonate' },
  { at: 4, label: 'Hydrate / acid salt', note: '·H₂O · HCO₃⁻ · HSO₄⁻' },
  { at: 5, label: 'Complex & alloy', note: 'ammines · oxometallates · brass' },
];

export default function DeepForge({ active, depth, onToggle }) {
  const reached = TIERS.filter((t) => depth >= t.at).length;

  return (
    <div
      className={`mx-3 mt-3 rounded-xl border p-3 transition ${
        active ? 'border-primary/45 bg-primary/[0.07]' : 'border-border bg-secondary/30'
      }`}
    >
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="type-display text-[11px] tracking-[0.16em] text-primary">DEEP FORGE</p>
          <p className="mt-0.5 text-[10px] text-muted-foreground">
            {active ? 'Advanced bonding online' : 'Locked · binary bonds only'}
          </p>
        </div>
        <button
          onClick={onToggle}
          className={`inline-flex shrink-0 items-center gap-1 rounded-full border px-2 py-1 type-tech text-[9px] uppercase tracking-wider transition ${
            active
              ? 'border-primary/60 bg-primary/15 text-primary'
              : 'border-border bg-background text-muted-foreground hover:text-foreground'
          }`}
        >
          {active ? <Sparkles size={10} /> : <Lock size={10} />}
          {active ? 'Active' : 'Unlock'}
        </button>
      </div>

      <ul className="mt-2.5 space-y-1.5">
        {TIERS.map((t, i) => {
          const open = active || i < 2;
          const lit = open && depth >= t.at;
          return (
            <li key={t.label} className="flex items-start gap-2">
              <span
                className={`mt-[5px] h-1.5 w-1.5 shrink-0 rounded-full ${
                  lit ? 'bg-primary' : open ? 'bg-muted-foreground/45' : 'bg-muted-foreground/20'
                }`}
              />
              <span className={`text-[10px] leading-tight ${open ? 'text-foreground/90' : 'text-muted-foreground/45'}`}>
                {t.label}
                <span className="block text-[9px] text-muted-foreground/70">{t.note}</span>
              </span>
            </li>
          );
        })}
      </ul>

      <p className="mt-2 border-t border-border/60 pt-2 text-[9px] leading-relaxed text-muted-foreground/70">
        {active
          ? `Deepest structure: ${depth} element${depth === 1 ? '' : 's'} (tier ${reached}). Keep stacking — hydrates, complexes and alloys are open.`
          : 'Deep Forge unlocks coordination complexes, alloys and metal-matrix structures.'}
      </p>
    </div>
  );
}