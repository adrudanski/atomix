import { useEffect, useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Check, Cpu, Loader2, Plug, RefreshCw, Unplug } from 'lucide-react';
import {
  DEFAULT_BASE,
  detectModel,
  normalizeBase,
  readLocalModel,
  writeLocalModel,
} from '@/lib/localModel';
import { STANDALONE } from '@/lib/standalone';

const STEPS = [
  'LM Studio → Developer tab → Start Server (port 1234).',
  // The Mac app adds the CORS headers itself, so there is nothing to switch on.
  ...(STANDALONE ? [] : ['In that same server panel, switch Enable CORS on.']),
  'Load a model in LM Studio, or leave Just-in-time loading on.',
];

export default function LocalModelDialog({ open, onOpenChange }) {
  const [base, setBase] = useState(DEFAULT_BASE);
  const [current, setCurrent] = useState('');
  const [models, setModels] = useState([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!open) return;
    const cfg = readLocalModel();
    setBase(cfg?.base || DEFAULT_BASE);
    setCurrent(cfg?.model || '');
    setModels([]);
    setError('');
  }, [open]);

  const detect = async () => {
    setBusy(true);
    setError('');
    try {
      const found = await detectModel(base);
      setModels(found.models);
      setBase(found.base);
      if (found.models.length) return;
      setError(
        found.blocked
          ? 'Nothing answered on 127.0.0.1 or localhost. The browser could not reach the server.'
          : 'The server answered but lists no model. Load a model, then detect again.'
      );
    } finally {
      setBusy(false);
    }
  };

  const use = (id) => {
    writeLocalModel({ base: normalizeBase(base), model: id });
    setCurrent(id);
    onOpenChange(false);
  };

  const disconnect = () => {
    writeLocalModel(null);
    setCurrent('');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto border-border bg-card sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="type-display flex items-center gap-2 text-base font-bold text-foreground">
            <Cpu size={16} className="text-primary" /> Local model · LM Studio
          </DialogTitle>
          <DialogDescription className="text-xs leading-relaxed text-muted-foreground">
            Conversations run entirely on this Mac — nothing is sent to a server. Load a model in LM Studio, start
            its local server, then detect it here.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3 pt-1">
          <label className="block">
            <span className="type-tech text-[10px] uppercase tracking-widest text-muted-foreground">
              Server address
            </span>
            <div className="mt-1 flex gap-1.5">
              <input
                value={base}
                onChange={(e) => setBase(e.target.value)}
                spellCheck={false}
                placeholder={DEFAULT_BASE}
                className="h-9 flex-1 rounded-lg border border-border bg-background px-2.5 type-tech text-[11px] text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-1 focus:ring-primary/60"
              />
              <button
                onClick={detect}
                disabled={busy}
                className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-primary/40 bg-primary/10 px-3 text-[11px] font-semibold text-primary transition hover:bg-primary/20 disabled:opacity-50"
              >
                {busy ? <Loader2 size={12} className="animate-spin" /> : <RefreshCw size={12} />}
                Detect
              </button>
            </div>
          </label>

          {current && (
            <p className="flex items-center gap-1.5 rounded-lg border border-primary/30 bg-primary/5 px-2.5 py-2 text-[11px] text-primary">
              <Check size={12} /> Connected to <span className="type-tech">{current}</span>
            </p>
          )}

          {models.length > 0 && (
            <div className="space-y-1.5">
              <span className="type-tech text-[10px] uppercase tracking-widest text-muted-foreground">
                Available models
              </span>
              <div className="max-h-48 space-y-1.5 overflow-y-auto pr-1">
                {models.map((id) => (
                  <button
                    key={id}
                    onClick={() => use(id)}
                    className={`flex w-full items-center gap-2 rounded-lg border px-2.5 py-2 text-left type-tech text-[11px] transition ${
                      current === id
                        ? 'border-primary/50 bg-primary/10 text-primary'
                        : 'border-border bg-secondary/40 text-foreground hover:border-primary/40'
                    }`}
                  >
                    <Plug size={12} className="shrink-0" />
                    <span className="truncate">{id}</span>
                    {current === id && <Check size={12} className="ml-auto shrink-0" />}
                  </button>
                ))}
              </div>
            </div>
          )}

          {error && <p className="text-[11px] leading-relaxed text-destructive">{error}</p>}

          <div className="rounded-lg border border-border bg-secondary/30 px-2.5 py-2">
            <p className="type-tech text-[10px] uppercase tracking-widest text-muted-foreground">Checklist</p>
            <ol className="mt-1.5 space-y-1 text-[10px] leading-relaxed text-muted-foreground">
              {STEPS.map((s, i) => (
                <li key={s} className="flex gap-1.5">
                  <span className="text-primary">{i + 1}.</span>
                  {s}
                </li>
              ))}
            </ol>
            {!STANDALONE && (
              <p className="mt-1.5 border-t border-border/60 pt-1.5 text-[10px] leading-relaxed text-muted-foreground">
                Still nothing? Open this app in a new browser tab — a secure page sometimes blocks calls to
                127.0.0.1.
              </p>
            )}
          </div>

          {current && (
            <button
              onClick={disconnect}
              className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-secondary/50 px-2.5 py-1.5 text-[11px] text-muted-foreground transition hover:text-foreground"
            >
              <Unplug size={12} /> {STANDALONE ? 'Disconnect this model' : 'Disconnect and use the built-in AI'}
            </button>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}