import { useState } from 'react';
import { Search, X } from 'lucide-react';
import { ELEMENTS, CATEGORIES } from '@/data/elements';

export default function ElementPicker({ onAdd }) {
  const [q, setQ] = useState('');
  const term = q.trim().toLowerCase();

  const list = term
    ? ELEMENTS.filter((e) =>
        e.name.toLowerCase().includes(term) ||
        e.symbol.toLowerCase() === term ||
        String(e.Z) === term ||
        e.symbol.toLowerCase().startsWith(term)
      )
    : ELEMENTS;

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="border-b border-border px-3 py-2.5">
        <div className="flex items-center gap-2 rounded-lg border border-border bg-secondary/30 px-2.5 py-1.5 transition focus-within:border-primary/50">
          <Search size={12} className="shrink-0 text-muted-foreground" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search element…"
            className="w-full bg-transparent text-xs text-foreground placeholder:text-muted-foreground focus:outline-none"
          />
          {q && (
            <button onClick={() => setQ('')} className="text-muted-foreground hover:text-foreground">
              <X size={11} />
            </button>
          )}
        </div>
        <p className="mt-2 type-tech text-[9px] uppercase tracking-widest text-muted-foreground/60">
          {list.length} elements · click to place
        </p>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto p-2">
        <div className="grid grid-cols-6 gap-1 lg:grid-cols-4">
          {list.map((el) => {
            const c = CATEGORIES[el.cat].color;
            return (
              <button
                key={el.Z}
                onClick={() => onAdd(el)}
                title={`${el.name} — ${el.state} at room temperature`}
                className="group relative flex flex-col items-center justify-center overflow-hidden rounded-md border py-1.5 transition hover:-translate-y-px hover:brightness-125"
                style={{
                  borderColor: `${c}4d`,
                  background: `linear-gradient(160deg, ${c}22, ${c}0a 70%)`,
                  boxShadow: `inset 0 1px 0 rgba(255,255,255,0.06)`,
                }}
              >
                <span className="type-tech text-[8px] leading-none text-muted-foreground/80">{el.Z}</span>
                <span className="mt-0.5 text-[13px] font-bold leading-none" style={{ color: c }}>
                  {el.symbol}
                </span>
                <span
                  className="absolute inset-x-1 bottom-0.5 h-px opacity-40 group-hover:opacity-100"
                  style={{ background: c }}
                />
              </button>
            );
          })}
        </div>
        {!list.length && (
          <p className="py-6 text-center text-xs text-muted-foreground">No element matches that.</p>
        )}
      </div>
    </div>
  );
}