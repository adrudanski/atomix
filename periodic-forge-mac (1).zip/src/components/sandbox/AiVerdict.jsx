const ENERGY_LABEL = {
  violent: 'Violent / explosive',
  strong: 'Strongly exothermic',
  moderate: 'Moderate',
  mild: 'Mild / slow',
  none: 'No reaction',
};

export default function AiVerdict({ verdict }) {
  const reacted = verdict.happens && verdict.energy !== 'none';

  return (
    <div
      className={`rounded-xl border p-3 ${
        reacted
          ? 'border-primary/40 bg-primary/5'
          : 'border-border bg-secondary/30'
      }`}
    >
      <div className="flex items-center justify-between gap-2">
        <p className="type-tech text-[10px] uppercase tracking-widest text-primary">
          AI verified
        </p>
        <span
          className={`shrink-0 rounded-full px-2 py-0.5 text-[9px] uppercase ${
            reacted ? 'bg-emerald-500/15 text-emerald-300' : 'bg-muted text-muted-foreground'
          }`}
        >
          {reacted ? ENERGY_LABEL[verdict.energy] || 'reacts' : 'no reaction'}
        </span>
      </div>

      <p className="mt-1.5 break-words text-sm font-semibold text-foreground">{verdict.equation}</p>
      {verdict.product && (
        <p className="mt-1 text-xs font-medium text-foreground/80">{verdict.product}</p>
      )}

      {verdict.observation && (
        <p className="mt-1.5 text-[11px] leading-relaxed text-muted-foreground">
          <span className="text-foreground/70">You would see:</span> {verdict.observation}
        </p>
      )}
      {verdict.conditions && (
        <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">
          <span className="text-foreground/70">Conditions:</span> {verdict.conditions}
        </p>
      )}
      {verdict.notes && (
        <p className="mt-1.5 border-t border-border/60 pt-1.5 text-[11px] leading-relaxed text-muted-foreground/90">
          {verdict.notes}
        </p>
      )}
    </div>
  );
}