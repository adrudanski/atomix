import { useState } from 'react';
import { Sparkles, Copy, Check } from 'lucide-react';
import { CATEGORIES, byZ } from '@/data/elements';
import { statesOf } from '@/data/reactions';
import { BONDS } from '@/data/bonds';

const ENERGY_STYLE = {
  violent: 'text-red-400 border-red-500/40 bg-red-500/10',
  strong: 'text-orange-300 border-orange-500/40 bg-orange-500/10',
  moderate: 'text-yellow-200 border-yellow-500/40 bg-yellow-500/10',
  mild: 'text-emerald-300 border-emerald-500/40 bg-emerald-500/10',
  none: 'text-muted-foreground border-border bg-muted/30',
};

const ENERGY_LABEL = {
  violent: 'Violent / explosive',
  strong: 'Strongly exothermic',
  moderate: 'Moderate',
  mild: 'Mild / slow',
  none: 'No reaction',
};

function BondBadge({ bond }) {
  const meta = BONDS[bond];
  if (!meta) return null;
  return (
    <span
      className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[9px] uppercase tracking-wider"
      style={{ color: meta.color, background: `${meta.color}1f`, border: `1px solid ${meta.color}59` }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: meta.color }} />
      {meta.label}
    </span>
  );
}

function CopyButton({ text }) {
  const [done, setDone] = useState(false);
  return (
    <button
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
          setDone(true);
          setTimeout(() => setDone(false), 1600);
        } catch (err) {
          /* clipboard blocked — say nothing */
        }
      }}
      className="inline-flex shrink-0 items-center gap-1 rounded-md border border-border bg-background/60 px-1.5 py-1 text-[9px] text-muted-foreground transition hover:text-foreground"
    >
      {done ? <Check size={9} /> : <Copy size={9} />}
      {done ? 'Copied' : 'Copy'}
    </button>
  );
}

function Composition({ set }) {
  if (!set?.length) return null;
  return (
    <div className="mt-1.5 flex flex-wrap gap-1">
      {set.map((Z) => (
        <span
          key={Z}
          title={byZ[Z]?.name}
          className="rounded border border-border bg-background/60 px-1.5 py-0.5 type-tech text-[9px] text-muted-foreground"
        >
          {byZ[Z]?.symbol}
        </span>
      ))}
    </div>
  );
}

export default function OutcomePanel({ result, selected, history, onAddSuggestion, onUnlock }) {
  const bond = result?.bond ? BONDS[result.bond] : null;

  return (
    <div className="flex h-full flex-col gap-3 overflow-y-auto p-4">
      <div>
        <h2 className="type-display text-sm text-primary">OUTCOME</h2>
        <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">
          Drop a specimen onto another to bond them. Compounds stay in the chamber, so you can keep stacking.
        </p>
      </div>

      {result ? (
        <div
          className={`rounded-xl border p-3 ${
            result.locked
              ? 'border-amber-500/40 bg-amber-500/10 text-amber-200'
              : ENERGY_STYLE[result.energy] || ENERGY_STYLE.none
          }`}
        >
          <div className="flex items-start justify-between gap-2">
            <p className="type-tech text-[10px] uppercase tracking-widest opacity-80">
              {result.locked ? 'Deep Forge required' : ENERGY_LABEL[result.energy] || 'Outcome'}
            </p>
            <BondBadge bond={result.bond} />
          </div>
          <div className="mt-1 flex items-start justify-between gap-2">
            <p className="break-words text-sm font-semibold text-foreground">{result.equation}</p>
            <CopyButton text={`${result.equation} — ${result.product}`} />
          </div>
          <p className="mt-1 text-xs font-medium opacity-90">{result.product}</p>
          <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">{result.description}</p>

          {result.locked && (
            <button
              onClick={onUnlock}
              className="mt-2 inline-flex items-center gap-1.5 rounded-lg border border-primary/50 bg-primary/10 px-2.5 py-1.5 text-[10px] font-medium text-primary transition hover:bg-primary/20"
            >
              <Sparkles size={11} /> Unlock Deep Forge
            </button>
          )}

          {bond && (
            <p className="mt-2 border-t border-border/50 pt-2 text-[10px] leading-relaxed text-muted-foreground/90">
              {bond.blurb}
            </p>
          )}

          <Composition set={result.set} />

          {result.suggestions?.length > 0 && (
            <div className="mt-2 border-t border-border/50 pt-2">
              <p className="type-tech text-[9px] uppercase tracking-widest text-muted-foreground/80">
                Complete the structure
              </p>
              <div className="mt-1 flex flex-wrap gap-1">
                {result.suggestions.map((s) => (
                  <button
                    key={s.formula}
                    onClick={() => onAddSuggestion(s.symbol)}
                    title={`Add ${s.symbol} to build ${s.formula}`}
                    className="rounded-md border border-border bg-background/60 px-1.5 py-1 text-[10px] text-foreground transition hover:border-primary/50 hover:text-primary"
                  >
                    +{s.symbol} → {s.formula}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="rounded-xl border border-dashed border-border bg-secondary/20 p-4">
          <p className="text-xs leading-relaxed text-muted-foreground">
            Drag one specimen onto another to see what happens. Reactants that do not combine stay in the chamber.
          </p>
        </div>
      )}

      {selected && (
        <div className="rounded-xl border border-border bg-secondary/40 p-3">
          <p className="type-tech text-[10px] uppercase tracking-widest text-muted-foreground">In hand</p>
          <div className="mt-1 flex items-center justify-between gap-2">
            <p className="text-sm font-semibold text-foreground">
              {selected.label}
              {selected.kind === 'element' && (
                <span className="ml-1 text-xs font-normal text-muted-foreground">({selected.name})</span>
              )}
            </p>
            <BondBadge bond={selected.bond} />
          </div>

          {selected.kind === 'element' ? (
            <>
              <p className="mt-1 text-[11px] text-muted-foreground">
                {CATEGORIES[selected.cat].label} · {selected.state} at 20 °C
              </p>
              <p className="mt-0.5 type-tech text-[10px] text-muted-foreground/80">
                Oxidation states: {statesOf(byZ[selected.Z]).join(', ') || '—'}
              </p>
            </>
          ) : (
            <>
              <p className="mt-1 text-[11px] text-muted-foreground">{selected.name}</p>
              <p className="mt-0.5 text-[11px] text-muted-foreground/80">
                Built from {selected.set.length} elements — drag it onto another specimen to go further.
              </p>
              <Composition set={selected.set} />
            </>
          )}
          <p className="mt-1 text-[11px] text-muted-foreground/80">
            Heat, Air and Water act on the selected specimen.
          </p>
        </div>
      )}

      {history.length > 0 && (
        <div>
          <p className="type-tech mb-1.5 text-[10px] uppercase tracking-widest text-muted-foreground">
            Reaction log
          </p>
          <ul className="space-y-1">
            {history.map((h) => (
              <li
                key={h.id}
                className="flex items-center justify-between gap-2 rounded-md border border-border/60 bg-secondary/30 px-2 py-1.5"
              >
                <span className="truncate type-tech text-[10px] text-muted-foreground">{h.equation}</span>
                <span className={`shrink-0 text-[9px] uppercase ${h.ok ? 'text-emerald-400' : 'text-muted-foreground'}`}>
                  {h.ok ? 'reacted' : 'inert'}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}

      <p className="mt-auto pt-2 text-[10px] leading-relaxed text-muted-foreground/70">
        Every element is modelled from its oxidation states, with balanced binary compounds, polyatomic salts and curated exceptions — qualitative, not a quantum simulation.
      </p>
    </div>
  );
}