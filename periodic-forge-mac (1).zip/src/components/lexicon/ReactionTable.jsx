import { useState } from 'react';
import { ENERGY } from '@/data/lexicon';

function EnergyBadge({ energy }) {
  const e = ENERGY[energy] || ENERGY.none;
  return (
    <span
      className={`inline-flex shrink-0 items-center rounded-full border px-1.5 py-0.5 type-tech text-[8px] uppercase tracking-wider ${e.cls}`}
    >
      {e.label}
    </span>
  );
}

function Row({ symbol, name, color, equation, product, energy, ok }) {
  return (
    <div
      className={`grid grid-cols-[auto_1fr_auto] items-start gap-2 rounded-lg border px-2 py-1.5 ${
        ok ? 'border-border/60 bg-secondary/20' : 'border-transparent bg-transparent opacity-60'
      }`}
    >
      <span
        className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-md text-[10px] font-bold"
        style={color ? { background: `${color}22`, color, border: `1px solid ${color}55` } : undefined}
      >
        {symbol}
      </span>
      <span className="min-w-0">
        <span className="type-tech block text-[10.5px] leading-snug text-foreground">{equation}</span>
        <span className="block truncate text-[10px] text-muted-foreground">{product}</span>
      </span>
      <EnergyBadge energy={energy} />
    </div>
  );
}

export function EnvironmentList({ rows }) {
  return (
    <div className="space-y-1.5">
      {rows.map((r) => (
        <div key={r.key}>
          <p className="mb-1 px-1 type-tech text-[8.5px] uppercase tracking-[0.16em] text-muted-foreground/70">
            {r.label}
          </p>
          <Row symbol={r.ok ? '✓' : '·'} equation={r.equation} product={r.product} energy={r.energy} ok={r.ok} />
        </div>
      ))}
    </div>
  );
}

export default function ReactionTable({ rows }) {
  const [onlyReactive, setOnlyReactive] = useState(true);
  const reactive = rows.filter((r) => r.ok);
  const shown = onlyReactive ? reactive : rows;

  return (
    <div>
      <div className="mb-1.5 flex items-center gap-1">
        <button
          onClick={() => setOnlyReactive(true)}
          className={`rounded-full border px-2 py-0.5 text-[9px] transition ${
            onlyReactive
              ? 'border-primary/50 bg-primary/10 text-primary'
              : 'border-border text-muted-foreground hover:text-foreground'
          }`}
        >
          Reacts · {reactive.length}
        </button>
        <button
          onClick={() => setOnlyReactive(false)}
          className={`rounded-full border px-2 py-0.5 text-[9px] transition ${
            !onlyReactive
              ? 'border-primary/50 bg-primary/10 text-primary'
              : 'border-border text-muted-foreground hover:text-foreground'
          }`}
        >
          All partners · {rows.length}
        </button>
      </div>
      <div className="space-y-1">
        {shown.map((r) => (
          <Row
            key={r.z}
            symbol={r.symbol}
            color={r.color}
            equation={r.equation}
            product={r.product}
            energy={r.energy}
            ok={r.ok}
          />
        ))}
      </div>
    </div>
  );
}