import { Link } from 'react-router-dom';
import { FlaskConical } from 'lucide-react';
import { CATEGORIES } from '@/data/elements';
import { EnvironmentList } from './ReactionTable';
import ReactionTable from './ReactionTable';

function Stat({ label, value }) {
  return (
    <div className="rounded-lg border border-border/60 bg-secondary/20 px-2 py-1.5">
      <p className="type-tech text-[8.5px] uppercase tracking-[0.14em] text-muted-foreground/70">{label}</p>
      <p className="mt-0.5 truncate text-[11.5px] text-foreground">{value}</p>
    </div>
  );
}

function Section({ title, hint, children }) {
  return (
    <section className="mt-4">
      <div className="mb-1.5 flex items-baseline justify-between gap-2">
        <h3 className="type-tech text-[9px] uppercase tracking-[0.18em] text-primary/90">{title}</h3>
        {hint && <span className="text-[9px] text-muted-foreground/70">{hint}</span>}
      </div>
      {children}
    </section>
  );
}

export default function ElementDossier({ d }) {
  const el = d.el;
  const c = CATEGORIES[el.cat].color;

  return (
    <div className="h-full overflow-y-auto px-4 pb-10 pt-4 md:px-6">
      <div
        className="relative overflow-hidden rounded-2xl border border-border/70 p-4"
        style={{ background: `linear-gradient(140deg, ${c}1f, transparent 62%)` }}
      >
        <div className="flex items-start gap-4">
          <div
            className="grid h-20 w-20 shrink-0 place-items-center rounded-2xl"
            style={{
              background: `linear-gradient(150deg, ${c}55 0%, ${c}22 60%, transparent 100%)`,
              border: `1px solid ${c}66`,
              boxShadow: `0 18px 40px -22px ${c}`,
            }}
          >
            <div className="text-center">
              <p className="type-tech text-[9px] leading-none text-muted-foreground">{el.Z}</p>
              <p className="text-2xl font-bold leading-tight" style={{ color: c }}>
                {el.symbol}
              </p>
              <p className="type-tech text-[8px] leading-none text-muted-foreground">{d.natural}</p>
            </div>
          </div>

          <div className="min-w-0 flex-1">
            <h2 className="type-display text-xl font-bold leading-tight text-foreground md:text-2xl">{el.name}</h2>
            <div className="mt-1 flex flex-wrap items-center gap-1.5">
              <span className="rounded-full px-2 py-0.5 text-[9px]" style={{ background: `${c}22`, color: c }}>
                {CATEGORIES[el.cat].label}
              </span>
              <span className="rounded-full border border-border px-2 py-0.5 text-[9px] text-muted-foreground">
                Period {el.period} · Group {el.group}
              </span>
              <span className="rounded-full border border-border px-2 py-0.5 text-[9px] text-muted-foreground">
                {d.blockLabel}
              </span>
              <span className="rounded-full border border-border px-2 py-0.5 text-[9px] capitalize text-muted-foreground">
                {el.state} at 20 °C
              </span>
            </div>
            <Link
              to={`/sandbox?element=${el.symbol}`}
              className="mt-2 inline-flex items-center gap-1.5 rounded-full border border-primary/40 bg-primary/10 px-2.5 py-1 type-tech text-[9px] uppercase tracking-widest text-primary transition hover:bg-primary/20"
            >
              <FlaskConical size={10} /> Open in sandbox
            </Link>
            <p className="mt-2 type-tech text-[10px] leading-relaxed text-muted-foreground">
              <span className="text-foreground/80">[core] </span>
              {d.config}
            </p>
            {d.note && <p className="mt-1.5 text-[11px] leading-relaxed text-muted-foreground">{d.note}</p>}
          </div>
        </div>
      </div>

      <Section title="Properties" hint={`${d.reactiveCount} of ${d.partners.length} reference partners react`}>
        <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
          <Stat label="Atomic mass" value={`${el.mass} u`} />
          <Stat label="Electronegativity" value={el.en == null ? 'not defined' : el.en.toFixed(2)} />
          <Stat label="Valence electrons" value={d.valence} />
          <Stat label="Natural form" value={d.natural} />
          <Stat label="Standard state" value={el.state} />
          <Stat label="Block" value={d.blockLabel} />
        </div>
      </Section>

      <Section title="Oxidation states">
        {d.states.length ? (
          <div className="flex flex-wrap gap-1">
            {d.states.map((s) => (
              <span key={s} className="rounded-md border border-border bg-secondary/40 px-2 py-0.5 type-tech text-[10px] text-foreground">
                {s}
              </span>
            ))}
          </div>
        ) : (
          <p className="text-[11px] text-muted-foreground">
            No stable oxidation state — {el.name.toLowerCase()} does not share or exchange electrons in compounds.
          </p>
        )}
        <p className="mt-1.5 text-[10px] leading-relaxed text-muted-foreground/80">{d.reactivity.text}</p>
      </Section>

      <Section title="Bonds it can form" hint={`${d.bonds.length} bond classes`}>
        <div className="grid gap-1.5 sm:grid-cols-2">
          {d.bonds.map((b) => (
            <div key={b.type} className="rounded-lg border border-border/60 bg-secondary/15 p-2">
              <div className="flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: b.color }} />
                <p className="text-[11px] font-semibold" style={{ color: b.color }}>
                  {b.label}
                </p>
                {b.partners.length > 0 && (
                  <span className="ml-auto type-tech text-[8.5px] text-muted-foreground">{b.partners.length} partners</span>
                )}
              </div>
              <p className="mt-1 text-[10px] leading-relaxed text-muted-foreground">{b.blurb}</p>
              {b.partners.length > 0 && (
                <p className="mt-1 type-tech text-[9px] text-foreground/70">with {b.partners.join(' · ')}</p>
              )}
            </div>
          ))}
        </div>
      </Section>

      <Section title="Environment reactions" hint="air · water · heat">
        <EnvironmentList rows={d.environment} />
      </Section>

      <Section title="Binary reaction set" hint="every reference partner">
        <ReactionTable rows={d.partners} />
      </Section>
    </div>
  );
}