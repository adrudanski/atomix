import { useEffect } from 'react';
import { Search, X, CornerDownRight } from 'lucide-react';
import { CATEGORIES } from '@/data/elements';

export default function ElementBrowser({ items, query, setQuery, cat, setCat, selectedZ, onSelect }) {
  useEffect(() => {
    const el = document.getElementById(`lex-row-${selectedZ}`);
    if (el) el.scrollIntoView({ block: 'nearest' });
  }, [selectedZ]);

  const step = (dir) => {
    const i = items.findIndex((d) => d.el.Z === selectedZ);
    const next = items[Math.min(items.length - 1, Math.max(0, (i < 0 ? 0 : i) + dir))];
    if (next) onSelect(next.el.Z);
  };

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="border-b border-border px-3 py-2.5">
        <div className="flex items-center gap-2 rounded-lg border border-border bg-secondary/30 px-2.5 py-1.5 transition focus-within:border-primary/50">
          <Search size={12} className="shrink-0 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'ArrowDown') {
                e.preventDefault();
                step(1);
              }
              if (e.key === 'ArrowUp') {
                e.preventDefault();
                step(-1);
              }
            }}
            placeholder="Search element, symbol, compound…"
            className="w-full bg-transparent text-xs text-foreground placeholder:text-muted-foreground focus:outline-none"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              aria-label="Clear search"
              className="text-muted-foreground transition hover:text-foreground"
            >
              <X size={11} />
            </button>
          )}
        </div>

        <div className="mt-2 flex flex-wrap gap-1">
          <button
            onClick={() => setCat('all')}
            className={`rounded-full border px-2 py-0.5 text-[9px] transition ${
              cat === 'all'
                ? 'border-primary/50 bg-primary/10 text-primary'
                : 'border-border text-muted-foreground hover:text-foreground'
            }`}
          >
            All 118
          </button>
          {Object.entries(CATEGORIES).map(([k, c]) => (
            <button
              key={k}
              onClick={() => setCat(cat === k ? 'all' : k)}
              className={`flex items-center gap-1 rounded-full border px-2 py-0.5 text-[9px] transition ${
                cat === k
                  ? 'border-foreground/30 bg-secondary text-foreground'
                  : 'border-border text-muted-foreground hover:text-foreground'
              }`}
            >
              <span className="h-1.5 w-1.5 rounded-full" style={{ background: c.color }} />
              {c.label}
            </button>
          ))}
        </div>

        <p className="mt-2 flex items-center gap-1 type-tech text-[9px] uppercase tracking-widest text-muted-foreground/60">
          {items.length} entries
          <span className="ml-auto hidden items-center gap-1 normal-case tracking-normal lg:flex">
            <CornerDownRight size={9} /> arrows to browse
          </span>
        </p>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto p-2">
        {items.map((d) => {
          const c = CATEGORIES[d.el.cat].color;
          const active = d.el.Z === selectedZ;
          return (
            <button
              key={d.el.Z}
              id={`lex-row-${d.el.Z}`}
              onClick={() => onSelect(d.el.Z)}
              aria-current={active ? 'true' : undefined}
              className={`mb-0.5 flex w-full items-center gap-2 rounded-lg border px-2 py-1.5 text-left transition ${
                active
                  ? 'border-primary/50 bg-primary/10'
                  : 'border-transparent hover:bg-secondary/50'
              }`}
            >
              <span className="w-6 shrink-0 type-tech text-[9px] text-muted-foreground">{d.el.Z}</span>
              <span
                className="grid h-6 w-6 shrink-0 place-items-center rounded-md text-[11px] font-bold"
                style={{ background: `${c}22`, color: c, border: `1px solid ${c}55` }}
              >
                {d.el.symbol}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-xs text-foreground">{d.el.name}</span>
                <span className="block truncate text-[9px] text-muted-foreground">
                  {CATEGORIES[d.el.cat].label} · {d.natural}
                </span>
              </span>
            </button>
          );
        })}
        {!items.length && (
          <p className="py-8 text-center text-xs text-muted-foreground">No entry matches that.</p>
        )}
      </div>
    </div>
  );
}