import base44 from "@base44/vite-plugin"
import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.dirname(fileURLToPath(import.meta.url))

// Desktop build: the Google Fonts @import is dropped (fonts are bundled from
// @fontsource-variable instead, see src/main.jsx) and the family names are
// pointed at the bundled variable fonts, so the app looks identical offline.
const bundledFonts = () => ({
  name: 'periodic-forge-bundled-fonts',
  enforce: 'pre',
  // The Base44-hosted touch icon is for "Add to Home Screen"; a Mac app does not need it.
  transformIndexHtml(html) {
    return html.replace(/<link\s+rel="apple-touch-icon"[^>]*>\s*/, '')
  },
  transform(code, id) {
    const file = id.split('?')[0]
    if (file.endsWith('/src/main.jsx')) {
      return {
        code:
          "import '@fontsource-variable/inter/wght.css';\n" +
          "import '@fontsource-variable/cinzel/index.css';\n" +
          "import '@fontsource-variable/jetbrains-mono/wght.css';\n" +
          code,
        map: null,
      }
    }
    if (!file.endsWith('/src/index.css')) return null
    return {
      code: code
        .replace(/@import url\('https:\/\/fonts\.googleapis\.com[^;]*;\s*/, '')
        .replace(/'Inter'/g, "'Inter Variable'")
        .replace(/'Cinzel'/g, "'Cinzel Variable'")
        .replace(/'JetBrains Mono'/g, "'JetBrains Mono Variable'"),
      map: null,
    }
  },
})

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  if (mode === 'standalone') {
    return {
      logLevel: 'error',
      // Absolute asset URLs are served by the app:// protocol in electron/main.cjs.
      base: '/',
      // Same "@/" alias the Base44 plugin normally provides.
      resolve: { alias: { '@': path.resolve(root, 'src') } },
      // Turns on STANDALONE in src/lib/standalone.js (no Base44 login, no hosted AI).
      define: { 'import.meta.env.VITE_STANDALONE': JSON.stringify('true') },
      plugins: [bundledFonts(), react()],
      build: { outDir: 'dist', chunkSizeWarningLimit: 4000 },
    }
  }

  return {
    logLevel: 'error', // Suppress warnings, only show errors
    plugins: [
      base44({
        // Support for legacy code that imports the base44 SDK with @/integrations, @/entities, etc.
        // can be removed if the code has been updated to use the new SDK imports from @base44/sdk
        legacySDKImports: process.env.BASE44_LEGACY_SDK_IMPORTS === 'true',
        hmrNotifier: true,
        navigationNotifier: true,
        analyticsTracker: true,
        visualEditAgent: true
      }),
      react(),
    ]
  }
});
