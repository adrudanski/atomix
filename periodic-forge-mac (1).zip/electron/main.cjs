// Periodic Forge — macOS shell.
//
// The app itself is the Vite build in ../dist. This file only opens it in a native
// window, serves it from a private app:// protocol (so routes like /sandbox, local
// storage and fonts behave exactly as on a website), and lets the AI lab talk to the
// user's LM Studio server on localhost.

const { app, BrowserWindow, Menu, protocol, session, shell } = require('electron');
const fs = require('node:fs');
const path = require('node:path');

const SCHEME = 'app';
const HOST = 'periodic-forge';
const ORIGIN = `${SCHEME}://${HOST}`;
const DIST = path.join(__dirname, '..', 'dist');
const IS_MAC = process.platform === 'darwin';

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.wasm': 'application/wasm',
  '.txt': 'text/plain; charset=utf-8',
};

// Everything the lab needs is bundled; the only network traffic is the optional
// call to the user's own LM Studio server.
const CSP = [
  "default-src 'self'",
  "script-src 'self' 'wasm-unsafe-eval'",
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: blob:",
  "font-src 'self' data:",
  "connect-src 'self' http://127.0.0.1:* http://localhost:* data: blob:",
  "worker-src 'self' blob:",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
].join('; ');

// Must run before the app is ready.
protocol.registerSchemesAsPrivileged([
  {
    scheme: SCHEME,
    privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true },
  },
]);

function respond(status, body, headers = {}) {
  return new Response(body, { status, headers });
}

async function serveApp(request) {
  const url = new URL(request.url);
  if (url.host !== HOST) return respond(404, 'Not found');

  let pathname;
  try {
    pathname = decodeURIComponent(url.pathname);
  } catch {
    return respond(400, 'Bad request');
  }

  let file = path.normalize(path.join(DIST, pathname));
  // Never serve anything outside the bundled app.
  if (file !== DIST && !file.startsWith(DIST + path.sep)) return respond(403, 'Forbidden');

  let isFile = false;
  try {
    isFile = (await fs.promises.stat(file)).isFile();
  } catch {
    isFile = false;
  }

  if (!isFile) {
    // A missing asset is a real 404; a missing route (/sandbox, /lexicon …) is the
    // single-page app, exactly like a web server with history fallback.
    if (path.extname(pathname)) return respond(404, 'Not found');
    file = path.join(DIST, 'index.html');
  }

  try {
    const body = await fs.promises.readFile(file);
    const type = MIME[path.extname(file).toLowerCase()] || 'application/octet-stream';
    const headers = { 'Content-Type': type, 'Cache-Control': 'no-cache' };
    if (type.startsWith('text/html')) headers['Content-Security-Policy'] = CSP;
    return respond(200, body, headers);
  } catch {
    return respond(500, 'Could not read the app bundle');
  }
}

// LM Studio only answers browsers that sit on an allowed origin, and "Enable CORS"
// is off by default. The app lives on its own app:// origin, so add the CORS headers
// to responses from the user's local model server — no setting to flip in LM Studio.
function allowLocalModelRequests() {
  const loopback = ['http://127.0.0.1:*/*', 'http://localhost:*/*'];
  session.defaultSession.webRequest.onHeadersReceived({ urls: loopback }, (details, callback) => {
    const responseHeaders = {};
    for (const [name, value] of Object.entries(details.responseHeaders || {})) {
      if (!/^access-control-/i.test(name)) responseHeaders[name] = value;
    }
    responseHeaders['Access-Control-Allow-Origin'] = ['*'];
    responseHeaders['Access-Control-Allow-Methods'] = ['GET, POST, OPTIONS'];
    responseHeaders['Access-Control-Allow-Headers'] = ['Content-Type, Authorization'];

    const reply = { responseHeaders };
    // A server that does not know CORS may answer the preflight with 404/405.
    if (details.method === 'OPTIONS') reply.statusLine = 'HTTP/1.1 204 No Content';
    callback(reply);
  });
}

let mainWindow = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 960,
    minHeight: 620,
    title: 'Periodic Forge',
    backgroundColor: '#04070d',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false,
    },
  });

  const openExternally = (url) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url).catch(() => {});
  };
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    openExternally(url);
    return { action: 'deny' };
  });
  mainWindow.webContents.on('will-navigate', (event, url) => {
    if (!url.startsWith(`${ORIGIN}/`)) {
      event.preventDefault();
      openExternally(url);
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  mainWindow.loadURL(`${ORIGIN}/`);
}

function buildMenu() {
  const template = [
    ...(IS_MAC ? [{ role: 'appMenu' }] : []),
    { role: 'fileMenu' },
    { role: 'editMenu' },
    { role: 'viewMenu' },
    { role: 'windowMenu' },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (!mainWindow) return;
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.focus();
  });

  app.whenReady().then(() => {
    protocol.handle(SCHEME, serveApp);
    allowLocalModelRequests();
    buildMenu();

    if (IS_MAC && app.dock) {
      const icon = path.join(__dirname, '..', 'build', 'icon.png');
      if (fs.existsSync(icon)) app.dock.setIcon(icon);
    }

    createWindow();

    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) createWindow();
    });
  });

  app.on('window-all-closed', () => {
    if (!IS_MAC) app.quit();
  });
}
